import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number"),
  role: text("role").default("farmer"),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Land listing model
export const landListings = pgTable("land_listings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  price: integer("price").notNull(),
  priceUnit: text("price_unit").notNull(), // per month, per season, etc.
  size: doublePrecision("size").notNull(), // in acres
  transactionType: text("transaction_type").notNull(), // rent, sale, lease
  features: jsonb("features").notNull(),
  images: text("images").array(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Equipment listing model
export const equipmentListings = pgTable("equipment_listings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  price: integer("price").notNull(),
  priceUnit: text("price_unit").notNull(), // per day, per hour, etc.
  equipmentType: text("equipment_type").notNull(),
  features: jsonb("features").notNull(),
  images: text("images").array(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Soil analysis model
export const soilAnalyses = pgTable("soil_analyses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").defaultNow(),
  location: text("location").notNull(),
  pHLevel: doublePrecision("ph_level"),
  nitrogen: doublePrecision("nitrogen"),
  phosphorus: doublePrecision("phosphorus"),
  potassium: doublePrecision("potassium"),
  organicMatter: doublePrecision("organic_matter"),
  soilHealthScore: integer("soil_health_score"),
  recommendations: jsonb("recommendations"),
});

// Crop recommendations model
export const cropRecommendations = pgTable("crop_recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  soilAnalysisId: integer("soil_analysis_id"),
  recommendations: jsonb("recommendations").notNull(),
  successProbability: integer("success_probability"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Weather forecasts model
export const weatherForecasts = pgTable("weather_forecasts", {
  id: serial("id").primaryKey(),
  location: text("location").notNull(),
  date: timestamp("date").notNull(),
  temperature: doublePrecision("temperature"),
  humidity: doublePrecision("humidity"),
  rainfall: doublePrecision("rainfall"),
  weatherCondition: text("weather_condition"),
});

// Market prices model
export const marketPrices = pgTable("market_prices", {
  id: serial("id").primaryKey(),
  crop: text("crop").notNull(),
  market: text("market").notNull(),
  variety: text("variety"),
  price: integer("price").notNull(),
  previousPrice: integer("previous_price"),
  unit: text("unit").default("quintal"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Government schemes model
export const governmentSchemes = pgTable("government_schemes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  department: text("department").notNull(),
  deadline: timestamp("deadline"),
  applicationProcess: text("application_process"),
  eligibility: text("eligibility"),
  benefits: text("benefits"),
  documentationRequired: jsonb("documentation_required"),
});

// Creating insert schemas for all models
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertLandListingSchema = createInsertSchema(landListings).omit({ id: true, createdAt: true });
export const insertEquipmentListingSchema = createInsertSchema(equipmentListings).omit({ id: true, createdAt: true });
export const insertSoilAnalysisSchema = createInsertSchema(soilAnalyses).omit({ id: true });
export const insertCropRecommendationSchema = createInsertSchema(cropRecommendations).omit({ id: true, createdAt: true });
export const insertWeatherForecastSchema = createInsertSchema(weatherForecasts).omit({ id: true });
export const insertMarketPriceSchema = createInsertSchema(marketPrices).omit({ id: true, updatedAt: true });
export const insertGovernmentSchemeSchema = createInsertSchema(governmentSchemes).omit({ id: true });

// Define types for DB operations
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLandListing = z.infer<typeof insertLandListingSchema>;
export type LandListing = typeof landListings.$inferSelect;

export type InsertEquipmentListing = z.infer<typeof insertEquipmentListingSchema>;
export type EquipmentListing = typeof equipmentListings.$inferSelect;

export type InsertSoilAnalysis = z.infer<typeof insertSoilAnalysisSchema>;
export type SoilAnalysis = typeof soilAnalyses.$inferSelect;

export type InsertCropRecommendation = z.infer<typeof insertCropRecommendationSchema>;
export type CropRecommendation = typeof cropRecommendations.$inferSelect;

export type InsertWeatherForecast = z.infer<typeof insertWeatherForecastSchema>;
export type WeatherForecast = typeof weatherForecasts.$inferSelect;

export type InsertMarketPrice = z.infer<typeof insertMarketPriceSchema>;
export type MarketPrice = typeof marketPrices.$inferSelect;

export type InsertGovernmentScheme = z.infer<typeof insertGovernmentSchemeSchema>;
export type GovernmentScheme = typeof governmentSchemes.$inferSelect;
