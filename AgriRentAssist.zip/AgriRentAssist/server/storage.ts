import {
  users, type User, type InsertUser,
  landListings, type LandListing, type InsertLandListing,
  equipmentListings, type EquipmentListing, type InsertEquipmentListing,
  soilAnalyses, type SoilAnalysis, type InsertSoilAnalysis,
  cropRecommendations, type CropRecommendation, type InsertCropRecommendation,
  weatherForecasts, type WeatherForecast, type InsertWeatherForecast,
  marketPrices, type MarketPrice, type InsertMarketPrice,
  governmentSchemes, type GovernmentScheme, type InsertGovernmentScheme
} from "@shared/schema";
import { db } from './db';
import { eq, like } from 'drizzle-orm';
import session from "express-session";
import connectPg from "connect-pg-simple";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

// Configure PostgreSQL session store
import createMemoryStore from "memorystore";
const PostgresSessionStore = connectPg(session);
const pool = {
  connectionString: process.env.DATABASE_URL,
};

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Authentication
  hashPassword(password: string): Promise<string>;
  comparePasswords(supplied: string, stored: string): Promise<boolean>;

  // Land listings operations
  getLandListings(): Promise<LandListing[]>;
  getLandListing(id: number): Promise<LandListing | undefined>;
  createLandListing(listing: InsertLandListing): Promise<LandListing>;
  updateLandListing(id: number, listing: Partial<InsertLandListing>): Promise<LandListing | undefined>;
  deleteLandListing(id: number): Promise<boolean>;

  // Equipment listings operations
  getEquipmentListings(): Promise<EquipmentListing[]>;
  getEquipmentListing(id: number): Promise<EquipmentListing | undefined>;
  createEquipmentListing(listing: InsertEquipmentListing): Promise<EquipmentListing>;
  updateEquipmentListing(id: number, listing: Partial<InsertEquipmentListing>): Promise<EquipmentListing | undefined>;
  deleteEquipmentListing(id: number): Promise<boolean>;

  // Soil analysis operations
  getSoilAnalyses(userId: number): Promise<SoilAnalysis[]>;
  getSoilAnalysis(id: number): Promise<SoilAnalysis | undefined>;
  createSoilAnalysis(analysis: InsertSoilAnalysis): Promise<SoilAnalysis>;

  // Crop recommendation operations
  getCropRecommendations(userId: number): Promise<CropRecommendation[]>;
  getCropRecommendation(id: number): Promise<CropRecommendation | undefined>;
  createCropRecommendation(recommendation: InsertCropRecommendation): Promise<CropRecommendation>;

  // Weather forecast operations
  getWeatherForecasts(location: string): Promise<WeatherForecast[]>;
  createWeatherForecast(forecast: InsertWeatherForecast): Promise<WeatherForecast>;

  // Market price operations
  getMarketPrices(location?: string): Promise<MarketPrice[]>;
  getMarketPrice(id: number): Promise<MarketPrice | undefined>;
  createMarketPrice(price: InsertMarketPrice): Promise<MarketPrice>;
  updateMarketPrice(id: number, price: Partial<InsertMarketPrice>): Promise<MarketPrice | undefined>;

  // Government scheme operations
  getGovernmentSchemes(): Promise<GovernmentScheme[]>;
  getGovernmentScheme(id: number): Promise<GovernmentScheme | undefined>;
  createGovernmentScheme(scheme: InsertGovernmentScheme): Promise<GovernmentScheme>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private landListings: Map<number, LandListing>;
  private equipmentListings: Map<number, EquipmentListing>;
  private soilAnalyses: Map<number, SoilAnalysis>;
  private cropRecommendations: Map<number, CropRecommendation>;
  private weatherForecasts: Map<number, WeatherForecast>;
  private marketPrices: Map<number, MarketPrice>;
  private governmentSchemes: Map<number, GovernmentScheme>;
  sessionStore: session.SessionStore;
  
  private currentUserId: number;
  private currentLandListingId: number;
  private currentEquipmentListingId: number;
  private currentSoilAnalysisId: number;
  private currentCropRecommendationId: number;
  private currentWeatherForecastId: number;
  private currentMarketPriceId: number;
  private currentGovernmentSchemeId: number;

  constructor() {
    this.users = new Map();
    this.landListings = new Map();
    this.equipmentListings = new Map();
    this.soilAnalyses = new Map();
    this.cropRecommendations = new Map();
    this.weatherForecasts = new Map();
    this.marketPrices = new Map();
    this.governmentSchemes = new Map();
    
    // Create memory session store
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    this.currentUserId = 1;
    this.currentLandListingId = 1;
    this.currentEquipmentListingId = 1;
    this.currentSoilAnalysisId = 1;
    this.currentCropRecommendationId = 1;
    this.currentWeatherForecastId = 1;
    this.currentMarketPriceId = 1;
    this.currentGovernmentSchemeId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }
  
  // Authentication methods
  async hashPassword(password: string): Promise<string> {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
  }

  async comparePasswords(supplied: string, stored: string): Promise<boolean> {
    if (!stored || !stored.includes(".")) return false;
    
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) return false;
    
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    
    // Hash the password before storing the user
    const hashedPassword = await this.hashPassword(insertUser.password);
    
    const user: User = { 
      ...insertUser, 
      password: hashedPassword, 
      id, 
      createdAt: new Date() 
    };
    
    this.users.set(id, user);
    return user;
  }

  // Land listings operations
  async getLandListings(): Promise<LandListing[]> {
    return Array.from(this.landListings.values());
  }

  async getLandListing(id: number): Promise<LandListing | undefined> {
    return this.landListings.get(id);
  }

  async createLandListing(listing: InsertLandListing): Promise<LandListing> {
    const id = this.currentLandListingId++;
    const landListing: LandListing = { ...listing, id, createdAt: new Date() };
    this.landListings.set(id, landListing);
    return landListing;
  }

  async updateLandListing(id: number, listing: Partial<InsertLandListing>): Promise<LandListing | undefined> {
    const existingListing = this.landListings.get(id);
    if (!existingListing) return undefined;

    const updatedListing = { ...existingListing, ...listing };
    this.landListings.set(id, updatedListing);
    return updatedListing;
  }

  async deleteLandListing(id: number): Promise<boolean> {
    return this.landListings.delete(id);
  }

  // Equipment listings operations
  async getEquipmentListings(): Promise<EquipmentListing[]> {
    return Array.from(this.equipmentListings.values());
  }

  async getEquipmentListing(id: number): Promise<EquipmentListing | undefined> {
    return this.equipmentListings.get(id);
  }

  async createEquipmentListing(listing: InsertEquipmentListing): Promise<EquipmentListing> {
    const id = this.currentEquipmentListingId++;
    const equipmentListing: EquipmentListing = { ...listing, id, createdAt: new Date() };
    this.equipmentListings.set(id, equipmentListing);
    return equipmentListing;
  }

  async updateEquipmentListing(id: number, listing: Partial<InsertEquipmentListing>): Promise<EquipmentListing | undefined> {
    const existingListing = this.equipmentListings.get(id);
    if (!existingListing) return undefined;

    const updatedListing = { ...existingListing, ...listing };
    this.equipmentListings.set(id, updatedListing);
    return updatedListing;
  }

  async deleteEquipmentListing(id: number): Promise<boolean> {
    return this.equipmentListings.delete(id);
  }

  // Soil analysis operations
  async getSoilAnalyses(userId: number): Promise<SoilAnalysis[]> {
    return Array.from(this.soilAnalyses.values()).filter(
      (analysis) => analysis.userId === userId
    );
  }

  async getSoilAnalysis(id: number): Promise<SoilAnalysis | undefined> {
    return this.soilAnalyses.get(id);
  }

  async createSoilAnalysis(analysis: InsertSoilAnalysis): Promise<SoilAnalysis> {
    const id = this.currentSoilAnalysisId++;
    const soilAnalysis: SoilAnalysis = { ...analysis, id };
    this.soilAnalyses.set(id, soilAnalysis);
    return soilAnalysis;
  }

  // Crop recommendation operations
  async getCropRecommendations(userId: number): Promise<CropRecommendation[]> {
    return Array.from(this.cropRecommendations.values()).filter(
      (recommendation) => recommendation.userId === userId
    );
  }

  async getCropRecommendation(id: number): Promise<CropRecommendation | undefined> {
    return this.cropRecommendations.get(id);
  }

  async createCropRecommendation(recommendation: InsertCropRecommendation): Promise<CropRecommendation> {
    const id = this.currentCropRecommendationId++;
    const cropRecommendation: CropRecommendation = { 
      ...recommendation, 
      id, 
      createdAt: new Date() 
    };
    this.cropRecommendations.set(id, cropRecommendation);
    return cropRecommendation;
  }

  // Weather forecast operations
  async getWeatherForecasts(location: string): Promise<WeatherForecast[]> {
    return Array.from(this.weatherForecasts.values()).filter(
      (forecast) => forecast.location.toLowerCase() === location.toLowerCase()
    );
  }

  async createWeatherForecast(forecast: InsertWeatherForecast): Promise<WeatherForecast> {
    const id = this.currentWeatherForecastId++;
    const weatherForecast: WeatherForecast = { ...forecast, id };
    this.weatherForecasts.set(id, weatherForecast);
    return weatherForecast;
  }

  // Market price operations
  async getMarketPrices(location?: string): Promise<MarketPrice[]> {
    const prices = Array.from(this.marketPrices.values());
    if (location) {
      return prices.filter(price => price.market.toLowerCase().includes(location.toLowerCase()));
    }
    return prices;
  }

  async getMarketPrice(id: number): Promise<MarketPrice | undefined> {
    return this.marketPrices.get(id);
  }

  async createMarketPrice(price: InsertMarketPrice): Promise<MarketPrice> {
    const id = this.currentMarketPriceId++;
    const marketPrice: MarketPrice = { ...price, id, updatedAt: new Date() };
    this.marketPrices.set(id, marketPrice);
    return marketPrice;
  }

  async updateMarketPrice(id: number, price: Partial<InsertMarketPrice>): Promise<MarketPrice | undefined> {
    const existingPrice = this.marketPrices.get(id);
    if (!existingPrice) return undefined;

    const updatedPrice = { 
      ...existingPrice, 
      ...price, 
      updatedAt: new Date() 
    };
    this.marketPrices.set(id, updatedPrice);
    return updatedPrice;
  }

  // Government scheme operations
  async getGovernmentSchemes(): Promise<GovernmentScheme[]> {
    return Array.from(this.governmentSchemes.values());
  }

  async getGovernmentScheme(id: number): Promise<GovernmentScheme | undefined> {
    return this.governmentSchemes.get(id);
  }

  async createGovernmentScheme(scheme: InsertGovernmentScheme): Promise<GovernmentScheme> {
    const id = this.currentGovernmentSchemeId++;
    const governmentScheme: GovernmentScheme = { ...scheme, id };
    this.governmentSchemes.set(id, governmentScheme);
    return governmentScheme;
  }

  // Initialize sample data
  private initializeData() {
    // Create sample user
    const sampleUser: InsertUser = {
      username: 'ajaysingh',
      password: 'securepassword',
      fullName: 'Ajay Singh',
      email: 'ajay.singh@example.com',
      phoneNumber: '+919876543210',
      role: 'farmer',
      profileImage: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80'
    };
    this.createUser(sampleUser);

    // Create sample land listings
    const landListings: InsertLandListing[] = [
      {
        userId: 1,
        title: '10 Acre Agricultural Land',
        description: 'Fertile agricultural land with good water sources and road access.',
        location: 'Pune, Maharashtra',
        price: 25000,
        priceUnit: 'month',
        size: 10,
        transactionType: 'rent',
        features: { irrigation: true, farmhouse: true, roadAccess: true },
        images: ['https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 18.5204,
        longitude: 73.8567,
        available: true
      },
      {
        userId: 1,
        title: '5 Acre Mango Orchard',
        description: 'Established mango orchard with 300 trees and well water system.',
        location: 'Ratnagiri, Maharashtra',
        price: 4500000,
        priceUnit: 'total',
        size: 5,
        transactionType: 'sale',
        features: { irrigation: true, trees: 300, roadAccess: true },
        images: ['https://images.unsplash.com/photo-1489657780376-e0d8630c4bd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 16.9902,
        longitude: 73.3120,
        available: true
      },
      {
        userId: 1,
        title: '15 Acre Paddy Fields',
        description: 'Well-maintained paddy fields with canal irrigation and storage facility.',
        location: 'Kolhapur, Maharashtra',
        price: 60000,
        priceUnit: 'season',
        size: 15,
        transactionType: 'lease',
        features: { irrigation: true, storage: true, nearMarket: true },
        images: ['https://images.unsplash.com/photo-1518002171953-a080ee817e1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 16.7050,
        longitude: 74.2433,
        available: true
      },
      // New land listings
      {
        userId: 1,
        title: '8 Acre Sugarcane Farm',
        description: 'Premium land for sugarcane cultivation with drip irrigation system installed.',
        location: 'Solapur, Maharashtra',
        price: 32000,
        priceUnit: 'acre/year',
        size: 8,
        transactionType: 'lease',
        features: { irrigation: true, soilType: 'black cotton', wellWater: true },
        images: ['https://images.unsplash.com/photo-1533910534207-90f31029a78e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 17.6599,
        longitude: 75.9064,
        available: true
      },
      {
        userId: 1,
        title: '12 Acre Rice Cultivation Land',
        description: 'Lowland area perfect for rice cultivation with natural water retention.',
        location: 'Nagpur, Maharashtra',
        price: 22000,
        priceUnit: 'acre/year',
        size: 12,
        transactionType: 'rent',
        features: { irrigation: true, soilType: 'alluvial', nearWaterBody: true },
        images: ['https://images.unsplash.com/photo-1505471768190-275e2ad070d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 21.1458,
        longitude: 79.0882,
        available: true
      },
      {
        userId: 1,
        title: '25 Acre Vineyard Area',
        description: 'Large property suitable for grape cultivation with controlled environment facility.',
        location: 'Nashik, Maharashtra',
        price: 7500000,
        priceUnit: 'total',
        size: 25,
        transactionType: 'sale',
        features: { irrigation: true, soilType: 'red', wellWater: true, controlledClimate: true },
        images: ['https://images.unsplash.com/photo-1547573854-74d2a71d0826?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 19.9975,
        longitude: 73.7898,
        available: true
      },
      {
        userId: 1,
        title: '6 Acre Vegetable Farming Land',
        description: 'Fertile soil perfect for vegetable cultivation with good market access.',
        location: 'Amravati, Maharashtra',
        price: 18000,
        priceUnit: 'acre/year',
        size: 6,
        transactionType: 'rent',
        features: { irrigation: true, soilType: 'loamy', organicCertified: true },
        images: ['https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 20.9320,
        longitude: 77.7523,
        available: true
      }
    ];

    landListings.forEach(listing => this.createLandListing(listing));

    // Create sample equipment listings
    const equipmentListings: InsertEquipmentListing[] = [
      {
        userId: 1,
        title: 'Tractor - John Deere 5045D',
        description: '45 HP tractor with hydraulic system, perfect for medium-sized farms.',
        location: 'Pune, Maharashtra',
        price: 1200,
        priceUnit: 'day',
        equipmentType: 'tractor',
        features: { horsepower: 45, hydraulic: true, attachments: true },
        images: ['https://images.unsplash.com/photo-1516431883659-655d41c09bf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 18.5204,
        longitude: 73.8567,
        available: true
      },
      {
        userId: 1,
        title: 'Thresher Machine',
        description: 'Heavy-duty thresher capable of processing various grain crops.',
        location: 'Nashik, Maharashtra',
        price: 800,
        priceUnit: 'day',
        equipmentType: 'thresher',
        features: { capacity: '2 tonnes/hour', portable: true, fuelEfficient: true },
        images: ['https://images.unsplash.com/photo-1593359863503-f598684c816d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 19.9975,
        longitude: 73.7898,
        available: true
      },
      // New equipment listings
      {
        userId: 1,
        title: 'Harvester - New Holland TC5.30',
        description: 'Modern combine harvester for efficient grain harvesting with experienced operator.',
        location: 'Nagpur, Maharashtra',
        price: 3500,
        priceUnit: 'day',
        equipmentType: 'harvester',
        features: { type: 'combine', capacity: '20 acres/day', operator: true },
        images: ['https://images.unsplash.com/photo-1623018035782-b269248df916?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 21.1458,
        longitude: 79.0882,
        available: true
      },
      {
        userId: 1,
        title: 'Rotavator - 7 feet',
        description: 'Heavy-duty rotavator for soil preparation with adjustable depth settings.',
        location: 'Solapur, Maharashtra',
        price: 800,
        priceUnit: 'day',
        equipmentType: 'tillage',
        features: { width: '7 feet', blades: 42, condition: 'excellent' },
        images: ['https://images.unsplash.com/photo-1586771107445-d3ca888129ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 17.6599,
        longitude: 75.9064,
        available: true
      },
      {
        userId: 1,
        title: 'Boom Sprayer - 600L Capacity',
        description: 'Tractor-mounted sprayer for efficient pesticide application with wide coverage.',
        location: 'Amravati, Maharashtra',
        price: 600,
        priceUnit: 'day',
        equipmentType: 'sprayer',
        features: { capacity: '600L', width: '12m', type: 'boom' },
        images: ['https://images.unsplash.com/photo-1595923533867-9a5b4d4b1e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 20.9320,
        longitude: 77.7523,
        available: true
      },
      {
        userId: 1,
        title: 'Seed Drill - 9 Row',
        description: 'Precision seed drill for accurate seed placement with adjustable row spacing.',
        location: 'Kolhapur, Maharashtra',
        price: 750,
        priceUnit: 'day',
        equipmentType: 'seeder',
        features: { rows: 9, spacing: 'adjustable', condition: 'good' },
        images: ['https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'],
        latitude: 16.7050,
        longitude: 74.2433,
        available: true
      }
    ];

    equipmentListings.forEach(listing => this.createEquipmentListing(listing));

    // Create sample soil analysis
    const soilAnalysis: InsertSoilAnalysis = {
      userId: 1,
      date: new Date('2023-06-15'),
      location: 'Pune, Maharashtra',
      pHLevel: 6.8,
      nitrogen: 35,
      phosphorus: 72,
      potassium: 68,
      organicMatter: 2.5,
      soilHealthScore: 78,
      recommendations: {
        fertilizer: 'NPK 14-7-7',
        lime: false,
        organicMatter: true
      }
    };
    this.createSoilAnalysis(soilAnalysis);

    // Create sample crop recommendations with comprehensive information for each crop type
    const cropRecommendation: InsertCropRecommendation = {
      userId: 1,
      soilAnalysisId: 1,
      recommendations: {
        crops: ['Wheat', 'Rice', 'Maize', 'Cotton', 'Sugarcane', 'Pulses'],
        cropDetails: {
          wheat: {
            season: "Rabi (October-March)",
            irrigationNeeds: "Medium (5-6 irrigations during crop cycle)",
            soilType: "Loamy to Clay Loam",
            fertilizers: {
              nitrogen: "120 kg/ha",
              phosphorus: "60 kg/ha",
              potassium: "40 kg/ha"
            }
          },
          rice: {
            season: "Kharif (June-September)",
            irrigationNeeds: "High (Requires standing water during most stages)",
            soilType: "Clay or Clay Loam",
            fertilizers: {
              nitrogen: "100 kg/ha",
              phosphorus: "50 kg/ha",
              potassium: "50 kg/ha"
            }
          },
          maize: {
            season: "Both Kharif and Rabi",
            irrigationNeeds: "Medium (Critical at flowering and grain filling)",
            soilType: "Well-drained Loamy",
            fertilizers: {
              nitrogen: "150 kg/ha",
              phosphorus: "75 kg/ha",
              potassium: "50 kg/ha"
            }
          },
          cotton: {
            season: "Kharif (May-November)",
            irrigationNeeds: "Medium to High (Especially during flowering and boll formation)",
            soilType: "Deep Black or Alluvial soils",
            fertilizers: {
              nitrogen: "100 kg/ha",
              phosphorus: "50 kg/ha",
              potassium: "50 kg/ha"
            }
          },
          sugarcane: {
            season: "Year-round (Plant crop: Feb-March or Oct-Nov)",
            irrigationNeeds: "High (Regular irrigation throughout growth)",
            soilType: "Deep, well-drained Loamy",
            fertilizers: {
              nitrogen: "250 kg/ha",
              phosphorus: "100 kg/ha",
              potassium: "120 kg/ha"
            }
          },
          pulses: {
            season: "Both Kharif and Rabi (depends on specific pulse)",
            irrigationNeeds: "Low to Medium (Depends on rainfall and variety)",
            soilType: "Well-drained Loamy or Sandy Loam",
            fertilizers: {
              nitrogen: "20 kg/ha",
              phosphorus: "60 kg/ha",
              potassium: "40 kg/ha"
            }
          }
        },
        season: "Varies by crop (see specific crop details)",
        irrigationNeeds: "Varies by crop (see specific crop details)"
      },
      successProbability: 85
    };
    this.createCropRecommendation(cropRecommendation);

    // Create sample weather forecasts
    const today = new Date();
    const weatherForecasts: InsertWeatherForecast[] = [
      {
        location: 'Pune, Maharashtra',
        date: new Date(today.setDate(today.getDate())),
        temperature: 25,
        humidity: 65,
        rainfall: 0,
        weatherCondition: 'Sunny'
      },
      {
        location: 'Pune, Maharashtra',
        date: new Date(today.setDate(today.getDate() + 1)),
        temperature: 23,
        humidity: 70,
        rainfall: 0,
        weatherCondition: 'Partly Cloudy'
      },
      {
        location: 'Pune, Maharashtra',
        date: new Date(today.setDate(today.getDate() + 1)),
        temperature: 22,
        humidity: 75,
        rainfall: 0,
        weatherCondition: 'Cloudy'
      },
      {
        location: 'Pune, Maharashtra',
        date: new Date(today.setDate(today.getDate() + 1)),
        temperature: 20,
        humidity: 85,
        rainfall: 12,
        weatherCondition: 'Rainy'
      },
      {
        location: 'Pune, Maharashtra',
        date: new Date(today.setDate(today.getDate() + 1)),
        temperature: 24,
        humidity: 68,
        rainfall: 0,
        weatherCondition: 'Sunny'
      }
    ];

    weatherForecasts.forEach(forecast => this.createWeatherForecast(forecast));

    // Create sample market prices
    const marketPrices: InsertMarketPrice[] = [
      {
        crop: 'Wheat',
        market: 'Pune APMC',
        variety: 'Standard',
        price: 2225,
        previousPrice: 2200,
        unit: 'quintal'
      },
      {
        crop: 'Rice (Basmati)',
        market: 'Nagpur APMC',
        variety: '1121',
        price: 3450,
        previousPrice: 3400,
        unit: 'quintal'
      },
      {
        crop: 'Soybean',
        market: 'Kolhapur APMC',
        variety: 'Yellow',
        price: 3850,
        previousPrice: 3865,
        unit: 'quintal'
      },
      {
        crop: 'Cotton',
        market: 'Amravati APMC',
        variety: 'Long Staple',
        price: 6120,
        previousPrice: 6000,
        unit: 'quintal'
      },
      {
        crop: 'Sugarcane',
        market: 'Sangli APMC',
        variety: 'Standard',
        price: 291,
        previousPrice: 295,
        unit: 'quintal'
      }
    ];

    marketPrices.forEach(price => this.createMarketPrice(price));

    // Create sample government schemes
    const governmentSchemes: InsertGovernmentScheme[] = [
      {
        title: 'PM Kisan Samman Nidhi',
        description: 'Direct income support of ₹6,000 per year',
        department: 'Ministry of Agriculture & Farmers Welfare',
        deadline: new Date('2023-06-30'),
        applicationProcess: 'Apply online through PM-Kisan portal or visit nearest CSC center',
        eligibility: 'All small and marginal farmers with cultivable land',
        benefits: 'Financial assistance of ₹6,000 per year in three equal installments',
        documentationRequired: {
          required: ['Aadhaar Card', 'Land Records', 'Bank Account Details']
        }
      },
      {
        title: 'Solar Irrigation Pump Subsidy',
        description: 'Get up to 90% subsidy on solar pumps',
        department: 'Ministry of New & Renewable Energy',
        applicationProcess: 'Apply through the state nodal agency or agriculture department',
        eligibility: 'Farmers with valid proof of land ownership or tenancy',
        benefits: 'Up to 90% subsidy on installation of solar irrigation pumps',
        documentationRequired: {
          required: ['Aadhaar Card', 'Land Ownership Documents', 'Bank Account Details', 'Existing Pump Details']
        }
      },
      {
        title: 'Farm Machinery Scheme',
        description: 'Subsidy on purchase of farm equipment',
        department: 'Department of Agriculture',
        deadline: new Date('2023-08-15'),
        applicationProcess: 'Apply at your district agriculture office',
        eligibility: 'Individual farmers, farmer groups, and cooperatives',
        benefits: '40-50% subsidy on purchase of approved farm machinery',
        documentationRequired: {
          required: ['Aadhaar Card', 'Land Records', 'Bank Account Details', 'Quotation from Authorized Dealer']
        }
      }
    ];

    governmentSchemes.forEach(scheme => this.createGovernmentScheme(scheme));
  }
}

export const storage = new MemStorage();
