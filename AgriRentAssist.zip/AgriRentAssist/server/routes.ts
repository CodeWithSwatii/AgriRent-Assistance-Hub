import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { setupAuth } from "./auth";
import {
  insertLandListingSchema,
  insertEquipmentListingSchema,
  insertSoilAnalysisSchema,
  insertCropRecommendationSchema,
  insertMarketPriceSchema,
  insertGovernmentSchemeSchema,
  insertUserSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  const router = express.Router();

  // User routes
  router.post("/users", async (req: Request, res: Response) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  router.get("/users/:id", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  // Land listing routes
  router.get("/land-listings", async (_req: Request, res: Response) => {
    const listings = await storage.getLandListings();
    res.json(listings);
  });

  router.get("/land-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    const listing = await storage.getLandListing(listingId);
    if (!listing) {
      return res.status(404).json({ message: "Land listing not found" });
    }
    res.json(listing);
  });

  router.post("/land-listings", async (req: Request, res: Response) => {
    try {
      const validatedData = insertLandListingSchema.parse(req.body);
      const listing = await storage.createLandListing(validatedData);
      res.status(201).json(listing);
    } catch (error) {
      res.status(400).json({ message: "Invalid land listing data", error });
    }
  });

  router.put("/land-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    try {
      const validatedData = insertLandListingSchema.partial().parse(req.body);
      const updatedListing = await storage.updateLandListing(listingId, validatedData);
      if (!updatedListing) {
        return res.status(404).json({ message: "Land listing not found" });
      }
      res.json(updatedListing);
    } catch (error) {
      res.status(400).json({ message: "Invalid land listing data", error });
    }
  });

  router.delete("/land-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    const deleted = await storage.deleteLandListing(listingId);
    if (!deleted) {
      return res.status(404).json({ message: "Land listing not found" });
    }
    res.status(204).end();
  });

  // Equipment listing routes
  router.get("/equipment-listings", async (_req: Request, res: Response) => {
    const listings = await storage.getEquipmentListings();
    res.json(listings);
  });

  router.get("/equipment-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    const listing = await storage.getEquipmentListing(listingId);
    if (!listing) {
      return res.status(404).json({ message: "Equipment listing not found" });
    }
    res.json(listing);
  });

  router.post("/equipment-listings", async (req: Request, res: Response) => {
    try {
      const validatedData = insertEquipmentListingSchema.parse(req.body);
      const listing = await storage.createEquipmentListing(validatedData);
      res.status(201).json(listing);
    } catch (error) {
      res.status(400).json({ message: "Invalid equipment listing data", error });
    }
  });

  router.put("/equipment-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    try {
      const validatedData = insertEquipmentListingSchema.partial().parse(req.body);
      const updatedListing = await storage.updateEquipmentListing(listingId, validatedData);
      if (!updatedListing) {
        return res.status(404).json({ message: "Equipment listing not found" });
      }
      res.json(updatedListing);
    } catch (error) {
      res.status(400).json({ message: "Invalid equipment listing data", error });
    }
  });

  router.delete("/equipment-listings/:id", async (req: Request, res: Response) => {
    const listingId = parseInt(req.params.id);
    const deleted = await storage.deleteEquipmentListing(listingId);
    if (!deleted) {
      return res.status(404).json({ message: "Equipment listing not found" });
    }
    res.status(204).end();
  });

  // Soil analysis routes
  router.get("/soil-analyses", async (req: Request, res: Response) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }
    const analyses = await storage.getSoilAnalyses(userId);
    res.json(analyses);
  });

  router.get("/soil-analyses/:id", async (req: Request, res: Response) => {
    const analysisId = parseInt(req.params.id);
    const analysis = await storage.getSoilAnalysis(analysisId);
    if (!analysis) {
      return res.status(404).json({ message: "Soil analysis not found" });
    }
    res.json(analysis);
  });

  router.post("/soil-analyses", async (req: Request, res: Response) => {
    try {
      const validatedData = insertSoilAnalysisSchema.parse(req.body);
      const analysis = await storage.createSoilAnalysis(validatedData);
      res.status(201).json(analysis);
    } catch (error) {
      res.status(400).json({ message: "Invalid soil analysis data", error });
    }
  });

  // Crop recommendation routes
  router.get("/crop-recommendations", async (req: Request, res: Response) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }
    const recommendations = await storage.getCropRecommendations(userId);
    res.json(recommendations);
  });

  router.get("/crop-recommendations/:id", async (req: Request, res: Response) => {
    const recommendationId = parseInt(req.params.id);
    const recommendation = await storage.getCropRecommendation(recommendationId);
    if (!recommendation) {
      return res.status(404).json({ message: "Crop recommendation not found" });
    }
    res.json(recommendation);
  });

  router.post("/crop-recommendations", async (req: Request, res: Response) => {
    try {
      const validatedData = insertCropRecommendationSchema.parse(req.body);
      const recommendation = await storage.createCropRecommendation(validatedData);
      res.status(201).json(recommendation);
    } catch (error) {
      res.status(400).json({ message: "Invalid crop recommendation data", error });
    }
  });

  // Weather forecast routes
  router.get("/weather-forecasts", async (req: Request, res: Response) => {
    const location = req.query.location as string;
    if (!location) {
      return res.status(400).json({ message: "Location is required" });
    }
    const forecasts = await storage.getWeatherForecasts(location);
    res.json(forecasts);
  });

  // Market price routes
  router.get("/market-prices", async (req: Request, res: Response) => {
    const location = req.query.location as string | undefined;
    const prices = await storage.getMarketPrices(location);
    res.json(prices);
  });

  router.get("/market-prices/:id", async (req: Request, res: Response) => {
    const priceId = parseInt(req.params.id);
    const price = await storage.getMarketPrice(priceId);
    if (!price) {
      return res.status(404).json({ message: "Market price not found" });
    }
    res.json(price);
  });

  // Government scheme routes
  router.get("/government-schemes", async (_req: Request, res: Response) => {
    const schemes = await storage.getGovernmentSchemes();
    res.json(schemes);
  });

  router.get("/government-schemes/:id", async (req: Request, res: Response) => {
    const schemeId = parseInt(req.params.id);
    const scheme = await storage.getGovernmentScheme(schemeId);
    if (!scheme) {
      return res.status(404).json({ message: "Government scheme not found" });
    }
    res.json(scheme);
  });

  // Register API routes
  app.use("/api", router);

  const httpServer = createServer(app);
  return httpServer;
}
