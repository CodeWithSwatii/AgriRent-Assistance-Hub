import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { HoverScale } from "@/components/ui/animations";
import { useToast } from "@/hooks/use-toast";

const Footer = () => {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success!",
      description: "You've been subscribed to our newsletter",
    });
    setEmail("");
  };

  return (
    <footer className="bg-primary-dark text-white mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="text-white text-2xl">
                <i className="ri-plant-line"></i>
              </div>
              <span className="font-heading font-bold text-xl">AgriRent</span>
            </div>
            <p className="text-neutral-200 text-sm mb-4">
              Revolutionizing agriculture with AI-powered insights, marketplace solutions, and real-time data.
            </p>
            <div className="flex space-x-4">
              <HoverScale>
                <Link href="#" className="text-white hover:text-accent transition-all">
                  <i className="ri-facebook-fill text-xl"></i>
                </Link>
              </HoverScale>
              <HoverScale>
                <Link href="#" className="text-white hover:text-accent transition-all">
                  <i className="ri-twitter-fill text-xl"></i>
                </Link>
              </HoverScale>
              <HoverScale>
                <Link href="#" className="text-white hover:text-accent transition-all">
                  <i className="ri-instagram-line text-xl"></i>
                </Link>
              </HoverScale>
              <HoverScale>
                <Link href="#" className="text-white hover:text-accent transition-all">
                  <i className="ri-youtube-fill text-xl"></i>
                </Link>
              </HoverScale>
            </div>
          </div>
          <div className="col-span-1">
            <h3 className="font-heading font-semibold text-lg mb-4">Features</h3>
            <ul className="space-y-2">
              <li><Link href="/crop-analysis" className="text-neutral-200 hover:text-white transition-all">Crop Optimization</Link></li>
              <li><Link href="/crop-analysis" className="text-neutral-200 hover:text-white transition-all">Soil Analysis</Link></li>
              <li><Link href="/weather" className="text-neutral-200 hover:text-white transition-all">Rainfall Prediction</Link></li>
              <li><Link href="/marketplace" className="text-neutral-200 hover:text-white transition-all">Land Marketplace</Link></li>
              <li><Link href="/marketplace" className="text-neutral-200 hover:text-white transition-all">Equipment Rental</Link></li>
              <li><Link href="/market-prices" className="text-neutral-200 hover:text-white transition-all">Market Prices</Link></li>
            </ul>
          </div>
          <div className="col-span-1">
            <h3 className="font-heading font-semibold text-lg mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Help Center</Link></li>
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Agricultural Guides</Link></li>
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Government Schemes</Link></li>
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Farming Tips</Link></li>
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Community Forum</Link></li>
              <li><Link href="#" className="text-neutral-200 hover:text-white transition-all">Partner Network</Link></li>
            </ul>
          </div>
          <div className="col-span-1">
            <h3 className="font-heading font-semibold text-lg mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="ri-map-pin-line text-accent mt-1 mr-2"></i>
                <span className="text-neutral-200">123 Farming Road, Agritech Tower, Pune, Maharashtra, India - 411001</span>
              </li>
              <li className="flex items-center">
                <i className="ri-phone-line text-accent mr-2"></i>
                <span className="text-neutral-200">+91 9876543210</span>
              </li>
              <li className="flex items-center">
                <i className="ri-mail-line text-accent mr-2"></i>
                <span className="text-neutral-200">support@agrirent.com</span>
              </li>
            </ul>
            <div className="mt-4">
              <h4 className="font-medium text-white mb-2">Subscribe to our newsletter</h4>
              <form onSubmit={handleSubscribe} className="flex">
                <Input
                  type="email"
                  placeholder="Your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-primary-dark border border-neutral-500 text-white rounded-r-none focus:border-accent"
                />
                <Button type="submit" className="bg-accent hover:bg-accent-dark text-neutral-800 rounded-l-none">
                  <i className="ri-send-plane-fill"></i>
                </Button>
              </form>
            </div>
          </div>
        </div>
        <div className="border-t border-neutral-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-neutral-300 text-sm mb-4 md:mb-0">
            © 2023 AgriRent Assistance Hub. All rights reserved.
          </div>
          <div className="flex space-x-6">
            <Link href="#" className="text-neutral-300 hover:text-white text-sm transition-all">Privacy Policy</Link>
            <Link href="#" className="text-neutral-300 hover:text-white text-sm transition-all">Terms of Service</Link>
            <Link href="#" className="text-neutral-300 hover:text-white text-sm transition-all">Cookie Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
