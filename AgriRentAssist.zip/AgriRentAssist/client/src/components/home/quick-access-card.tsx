import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { HoverScale } from "@/components/ui/animations";

const QuickAccessCard = () => {
  const [_, navigate] = useLocation();

  const quickAccessItems = [
    {
      title: "Crop Analysis",
      icon: "ri-leaf-line",
      href: "/crop-analysis",
    },
    {
      title: "Rent Equipment",
      icon: "ri-map-pin-line",
      href: "/marketplace",
    },
    {
      title: "Weather Forecast",
      icon: "ri-cloud-line",
      href: "/weather",
    },
    {
      title: "Market Prices",
      icon: "ri-line-chart-line",
      href: "/market-prices",
    },
  ];

  return (
    <motion.div
      initial={{ y: 10, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="relative bg-white rounded-xl shadow-2xl p-6 animate-fade-in"
    >
      <h2 className="font-heading font-semibold text-xl text-neutral-800 mb-4">Quick Access</h2>
      <div className="grid grid-cols-2 gap-4 mb-4">
        {quickAccessItems.map((item, index) => (
          <HoverScale key={index}>
            <button
              onClick={() => navigate(item.href)}
              className="bg-neutral-100 hover:bg-primary hover:text-white rounded-lg p-4 flex flex-col items-center justify-center transition-all"
            >
              <i className={`${item.icon} text-2xl mb-2 text-primary group-hover:text-white`}></i>
              <span className="text-sm font-medium">{item.title}</span>
            </button>
          </HoverScale>
        ))}
      </div>
      <div className="bg-neutral-50 rounded-lg p-4">
        <div className="flex items-center mb-3">
          <i className="ri-sun-line text-xl text-accent mr-2"></i>
          <h3 className="font-heading font-medium text-neutral-800">Today's Farming Tip</h3>
        </div>
        <p className="text-sm text-neutral-600">
          Consider applying organic mulch to conserve soil moisture and suppress weeds during the summer months.
        </p>
      </div>
    </motion.div>
  );
};

export default QuickAccessCard;
