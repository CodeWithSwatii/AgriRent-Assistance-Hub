import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function WelcomeDialog() {
  const [isVisible, setIsVisible] = useState(true);

  // Automatically hide the welcome dialog after 8 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 8000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black bg-opacity-30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="w-full max-w-md"
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            transition={{ type: 'spring', bounce: 0.4 }}
          >
            <Card className="p-6 shadow-xl border-none bg-white">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-primary mb-2">Welcome to AgriRent!</h3>
                <p className="text-neutral-600 mb-6">
                  Discover smart farming tools, land & equipment rentals, and market insights all in one place
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-3">
                  <Button 
                    className="bg-primary hover:bg-primary-dark" 
                    onClick={() => setIsVisible(false)}
                  >
                    Get Started
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsVisible(false)}
                  >
                    Explore Features
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}