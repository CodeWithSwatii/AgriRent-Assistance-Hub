import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import QuickAccessCard from "./quick-access-card";
import { SlideUp, FadeIn } from "@/components/ui/animations";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary to-primary-dark mb-12">
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1589923188651-268a9766d448?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80')",
          backgroundSize: "cover",
        }}
      ></div>
      <div className="relative z-10 px-8 py-16 md:py-24 flex flex-col md:flex-row items-center">
        <SlideUp className="w-full md:w-1/2 mb-8 md:mb-0">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-heading font-bold text-3xl md:text-4xl lg:text-5xl text-white mb-6"
          >
            Revolutionizing Agriculture & Farming Assistance
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-neutral-100 text-lg mb-8 max-w-lg"
          >
            Optimize crop growth, rent equipment, analyze soil health, predict rainfall, and access real-time market prices—all in one place.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex space-x-4"
          >
            <Link href="/auth">
              <Button size="lg" className="bg-accent hover:bg-accent-light text-neutral-800 font-medium shadow-lg hover:shadow-xl">
                Get Started
              </Button>
            </Link>
            <a href="#description-section">
              <Button
                size="lg"
                variant="outline"
                className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-white border-opacity-30"
              >
                Learn More
              </Button>
            </a>
          </motion.div>
        </SlideUp>
        <FadeIn className="w-full md:w-1/2 flex justify-center" delay={0.3}>
          <div className="relative w-full max-w-md">
            <QuickAccessCard />
            <div className="absolute -bottom-4 -right-4 -left-4 h-full bg-primary bg-opacity-20 rounded-xl -z-10"></div>
            <div className="absolute -bottom-8 -right-8 -left-8 h-full bg-primary bg-opacity-10 rounded-xl -z-20"></div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
};

export default HeroSection;
