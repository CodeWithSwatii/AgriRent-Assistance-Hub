import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import SoilAnalysisCard from "./soil-analysis-card";
import CropRecommendationCard from "./crop-recommendation-card";
import RainfallPredictionCard from "./rainfall-prediction-card";
import FertilizerRecommendationCard from "./fertilizer-recommendation-card";
import { StaggerChildren, StaggerItem } from "@/components/ui/animations";

interface SmartFarmingSectionProps {
  loading?: boolean;
}

const SmartFarmingSection = ({ loading = false }: SmartFarmingSectionProps) => {
  return (
    <section id="description-section" className="mb-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row items-center justify-between mb-6"
      >
        <div>
          <h2 className="font-heading font-bold text-2xl text-neutral-800">
            Smart Farming & Crop Optimization
          </h2>
          <p className="text-neutral-600 mt-1">AI-powered insights to maximize your crop yield</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Link href="/crop-analysis">
            <button className="text-primary hover:text-primary-dark font-medium flex items-center transition-all">
              <span>View all insights</span>
              <i className="ri-arrow-right-line ml-1"></i>
            </button>
          </Link>
        </div>
      </motion.div>

      <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StaggerItem>
          <SoilAnalysisCard loading={loading} />
        </StaggerItem>
        <StaggerItem>
          <CropRecommendationCard loading={loading} />
        </StaggerItem>
        <StaggerItem>
          <RainfallPredictionCard loading={loading} />
        </StaggerItem>
        <StaggerItem>
          <FertilizerRecommendationCard loading={loading} />
        </StaggerItem>
      </StaggerChildren>
    </section>
  );
};

export default SmartFarmingSection;
