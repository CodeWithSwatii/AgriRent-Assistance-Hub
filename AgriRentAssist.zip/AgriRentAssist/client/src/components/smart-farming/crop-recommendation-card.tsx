import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ScaleIn } from "@/components/ui/animations";

interface CropRecommendationCardProps {
  loading?: boolean;
}

const CropRecommendationCard = ({ loading = false }: CropRecommendationCardProps) => {
  const { toast } = useToast();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis Complete",
        description: "Detailed crop recommendations are ready for your review.",
      });
    }, 2000);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="skeleton h-10 w-10 rounded-lg mr-3"></div>
            <div className="skeleton h-6 w-40"></div>
          </div>
          <div className="skeleton h-4 w-full"></div>
        </div>
        <div className="p-5">
          <div className="mb-4">
            <div className="skeleton h-4 w-40 mb-2"></div>
            <div className="flex flex-wrap gap-2">
              <div className="skeleton h-6 w-16 rounded-full"></div>
              <div className="skeleton h-6 w-16 rounded-full"></div>
              <div className="skeleton h-6 w-16 rounded-full"></div>
            </div>
          </div>
          <div className="mb-4">
            <div className="skeleton h-4 w-40 mb-2"></div>
            <div className="skeleton h-4 w-full"></div>
          </div>
          <div className="skeleton h-10 w-full rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <ScaleIn delay={0.1}>
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="bg-accent bg-opacity-10 rounded-lg p-2 mr-3">
              <i className="ri-seedling-line text-xl text-accent"></i>
            </div>
            <h3 className="font-heading font-semibold text-lg">Crop Suggestions</h3>
          </div>
          <p className="text-sm text-neutral-600">
            AI recommendations based on soil, weather & irrigation
          </p>
        </div>
        <div className="p-5">
          <div className="mb-4">
            <h4 className="text-sm font-medium text-neutral-600 mb-2">Recommended Crops</h4>
            <div className="flex flex-wrap gap-2">
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 }}
                className="bg-primary bg-opacity-10 text-primary text-xs px-3 py-1 rounded-full"
              >
                Wheat
              </motion.span>
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="bg-primary bg-opacity-10 text-primary text-xs px-3 py-1 rounded-full"
              >
                Maize
              </motion.span>
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.3 }}
                className="bg-primary bg-opacity-10 text-primary text-xs px-3 py-1 rounded-full"
              >
                Soybean
              </motion.span>
            </div>
          </div>
          <div className="mb-4">
            <h4 className="text-sm font-medium text-neutral-600 mb-2">Success Probability</h4>
            <div className="flex items-center">
              <div className="h-2 flex-grow bg-neutral-200 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-success rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: "85%" }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                ></motion.div>
              </div>
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3, delay: 1 }}
                className="ml-2 text-sm font-medium text-success"
              >
                85%
              </motion.span>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full hover:bg-primary hover:text-white"
            onClick={handleAnalyze}
            disabled={isAnalyzing}
          >
            {isAnalyzing ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                Analyzing...
              </>
            ) : (
              "Get Detailed Analysis"
            )}
          </Button>
        </div>
      </div>
    </ScaleIn>
  );
};

export default CropRecommendationCard;
