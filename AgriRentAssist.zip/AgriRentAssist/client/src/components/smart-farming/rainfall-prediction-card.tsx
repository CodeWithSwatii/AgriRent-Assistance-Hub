import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { DAYS_OF_WEEK, WEATHER_ICONS } from "@/lib/constants";
import { ScaleIn } from "@/components/ui/animations";

interface RainfallPredictionCardProps {
  loading?: boolean;
}

const RainfallPredictionCard = ({ loading = false }: RainfallPredictionCardProps) => {
  const [location] = useState("Pune, Maharashtra");

  const { isLoading, data: forecasts } = useQuery({
    queryKey: [`/api/weather-forecasts?location=${encodeURIComponent(location)}`],
    enabled: !loading,
  });

  if (loading || isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="skeleton h-10 w-10 rounded-lg mr-3"></div>
            <div className="skeleton h-6 w-40"></div>
          </div>
          <div className="skeleton h-4 w-full"></div>
        </div>
        <div className="p-5">
          <div className="skeleton h-24 w-full rounded-lg mb-4"></div>
          <div className="grid grid-cols-5 gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="text-center">
                <div className="skeleton h-4 w-8 mx-auto mb-2"></div>
                <div className="skeleton h-8 w-8 mx-auto rounded-full mb-2"></div>
                <div className="skeleton h-4 w-8 mx-auto"></div>
              </div>
            ))}
          </div>
          <div className="skeleton h-10 w-full rounded-lg"></div>
        </div>
      </div>
    );
  }

  // Placeholder forecast data for visualization
  const forecastData = [
    { day: 0, value: 10 },
    { day: 1, value: 25 },
    { day: 2, value: 15 },
    { day: 3, value: 40 },
    { day: 4, value: 20 },
  ];

  return (
    <ScaleIn delay={0.2}>
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="bg-secondary bg-opacity-10 rounded-lg p-2 mr-3">
              <i className="ri-cloud-line text-xl text-secondary"></i>
            </div>
            <h3 className="font-heading font-semibold text-lg">Rainfall Prediction</h3>
          </div>
          <p className="text-sm text-neutral-600">AI forecasting for better decision making</p>
        </div>
        <div className="p-5">
          <div className="h-24 bg-neutral-100 rounded-lg mb-4 overflow-hidden relative">
            <div className="absolute inset-0 flex items-end p-2">
              {forecastData.map((item, index) => (
                <motion.div
                  key={index}
                  className="flex-1 flex justify-center"
                  initial={{ height: 0 }}
                  animate={{ height: `${item.value}%` }}
                  transition={{ duration: 0.8, delay: 0.1 * index }}
                >
                  <div
                    className="w-4 bg-secondary bg-opacity-70 rounded-t-sm"
                    style={{ height: "100%" }}
                  ></div>
                </motion.div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-5 gap-1 mb-4">
            {forecasts?.map((forecast, index) => {
              const date = new Date(forecast.date);
              const dayName = DAYS_OF_WEEK[date.getDay()];
              const icon = WEATHER_ICONS[forecast.weatherCondition] || "ri-cloudy-line";

              return (
                <motion.div
                  key={index}
                  className="text-center"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 * index }}
                >
                  <div className="text-xs text-neutral-500">{dayName}</div>
                  <div className="text-xl text-secondary">
                    <i className={icon}></i>
                  </div>
                  <div className="text-xs font-medium">{Math.round(forecast.temperature)}°</div>
                </motion.div>
              );
            })}
          </div>
          <Button
            variant="outline"
            className="w-full hover:bg-primary hover:text-white transition-all"
          >
            View Detailed Forecast
          </Button>
        </div>
      </div>
    </ScaleIn>
  );
};

export default RainfallPredictionCard;
