import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ScaleIn } from "@/components/ui/animations";

interface FertilizerRecommendationCardProps {
  loading?: boolean;
}

const FertilizerRecommendationCard = ({ loading = false }: FertilizerRecommendationCardProps) => {
  const { toast } = useToast();
  const [isRequesting, setIsRequesting] = useState(false);

  const handleRequest = () => {
    setIsRequesting(true);
    setTimeout(() => {
      setIsRequesting(false);
      toast({
        title: "Recommendation Ready",
        description: "Your fertilizer recommendation is now available.",
      });
    }, 2000);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="skeleton h-10 w-10 rounded-lg mr-3"></div>
            <div className="skeleton h-6 w-40"></div>
          </div>
          <div className="skeleton h-4 w-full"></div>
        </div>
        <div className="p-5">
          <div className="mb-4">
            <div className="skeleton h-4 w-40 mb-2"></div>
            <div className="grid grid-cols-3 gap-2">
              <div className="skeleton h-16 w-full rounded-lg"></div>
              <div className="skeleton h-16 w-full rounded-lg"></div>
              <div className="skeleton h-16 w-full rounded-lg"></div>
            </div>
          </div>
          <div className="skeleton h-6 w-full mb-4"></div>
          <div className="skeleton h-10 w-full rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <ScaleIn delay={0.3}>
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="bg-primary bg-opacity-10 rounded-lg p-2 mr-3">
              <i className="ri-flask-line text-xl text-primary"></i>
            </div>
            <h3 className="font-heading font-semibold text-lg">Fertilizer Guide</h3>
          </div>
          <p className="text-sm text-neutral-600">
            Personalized recommendations based on soil needs
          </p>
        </div>
        <div className="p-5">
          <div className="mb-4">
            <h4 className="text-sm font-medium text-neutral-600 mb-2">Key Nutrients Status</h4>
            <div className="grid grid-cols-3 gap-2">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.1 }}
                className="bg-neutral-100 p-2 rounded-lg"
              >
                <div className="text-xs text-neutral-500 mb-1">Nitrogen</div>
                <div className="text-sm font-medium text-warning">Low</div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="bg-neutral-100 p-2 rounded-lg"
              >
                <div className="text-xs text-neutral-500 mb-1">Phosphorus</div>
                <div className="text-sm font-medium text-success">Good</div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.3 }}
                className="bg-neutral-100 p-2 rounded-lg"
              >
                <div className="text-xs text-neutral-500 mb-1">Potassium</div>
                <div className="text-sm font-medium text-success">Good</div>
              </motion.div>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.5 }}
            className="text-sm text-neutral-600 mb-4"
          >
            <span className="text-warning font-medium">Recommended:</span> NPK 14-7-7 fertilizer
          </motion.div>
          <Button
            variant="outline"
            className="w-full hover:bg-primary hover:text-white"
            onClick={handleRequest}
            disabled={isRequesting}
          >
            {isRequesting ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                Processing...
              </>
            ) : (
              "Get Full Recommendation"
            )}
          </Button>
        </div>
      </div>
    </ScaleIn>
  );
};

export default FertilizerRecommendationCard;
