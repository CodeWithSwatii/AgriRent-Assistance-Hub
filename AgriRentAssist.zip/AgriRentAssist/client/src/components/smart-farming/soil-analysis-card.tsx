import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ScaleIn } from "@/components/ui/animations";

interface SoilAnalysisCardProps {
  loading?: boolean;
}

const SoilAnalysisCard = ({ loading = false }: SoilAnalysisCardProps) => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);

  const handleAnalyze = () => {
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      toast({
        title: "Analysis Complete",
        description: "Your soil analysis report has been processed successfully.",
      });
    }, 2000);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="skeleton h-10 w-10 rounded-lg mr-3"></div>
            <div className="skeleton h-6 w-40"></div>
          </div>
          <div className="skeleton h-4 w-full"></div>
        </div>
        <div className="p-5">
          <div className="flex justify-between mb-3">
            <div className="skeleton h-4 w-24"></div>
            <div className="skeleton h-4 w-24"></div>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div>
              <div className="skeleton h-4 w-32 mb-2"></div>
              <div className="skeleton h-6 w-16"></div>
            </div>
            <div className="skeleton h-16 w-24 rounded-lg"></div>
          </div>
          <div className="skeleton h-10 w-full rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <ScaleIn>
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
        <div className="p-5 border-b border-neutral-100">
          <div className="flex items-center mb-3">
            <div className="bg-primary bg-opacity-10 rounded-lg p-2 mr-3">
              <i className="ri-plant-line text-xl text-primary"></i>
            </div>
            <h3 className="font-heading font-semibold text-lg">Soil Analysis</h3>
          </div>
          <p className="text-sm text-neutral-600">
            Upload soil reports to get nutrient analysis and recommendations
          </p>
        </div>
        <div className="p-5">
          <div className="flex justify-between mb-3">
            <span className="text-sm font-medium text-neutral-600">Last Analysis</span>
            <span className="text-sm text-neutral-500">15 June 2023</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div>
              <div className="text-sm font-medium text-neutral-600 mb-1">Soil Health Score</div>
              <div className="flex items-center">
                <motion.span
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="text-xl font-bold text-primary"
                >
                  78
                </motion.span>
                <span className="text-sm text-success ml-2">+5</span>
              </div>
            </div>
            <div className="h-16 w-24 bg-neutral-100 rounded-lg overflow-hidden flex items-center justify-center">
              <motion.div
                initial={{ opacity: 0, rotate: -90 }}
                animate={{ opacity: 1, rotate: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <svg width="60" height="60" viewBox="0 0 60 60">
                  <circle cx="30" cy="30" r="24" fill="none" stroke="#e5e7eb" strokeWidth="6" />
                  <motion.circle
                    cx="30"
                    cy="30"
                    r="24"
                    fill="none"
                    stroke="#2D7738"
                    strokeWidth="6"
                    strokeDasharray="150.8"
                    strokeDashoffset="33.2"
                    initial={{ strokeDashoffset: 150.8 }}
                    animate={{ strokeDashoffset: 33.2 }}
                    transition={{ duration: 1, delay: 0.5 }}
                  />
                </svg>
              </motion.div>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full hover:bg-primary hover:text-white"
            onClick={handleAnalyze}
            disabled={isUploading}
          >
            {isUploading ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                Processing...
              </>
            ) : (
              "Analyze New Sample"
            )}
          </Button>
        </div>
      </div>
    </ScaleIn>
  );
};

export default SoilAnalysisCard;
