import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface RecommendationNotificationProps {
  show: boolean;
  onClose: () => void;
}

export default function RecommendationNotification({ show, onClose }: RecommendationNotificationProps) {
  // Auto-dismiss after 10 seconds
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 10000);
      
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed bottom-5 right-5 z-50 max-w-md"
          initial={{ opacity: 0, x: 50, y: 0 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          exit={{ opacity: 0, x: 50 }}
          transition={{ type: 'spring', bounce: 0.3 }}
        >
          <Card className="p-5 shadow-xl border-none bg-white">
            <div className="flex items-start gap-3">
              <div className="bg-success bg-opacity-10 rounded-full p-2 mt-1">
                <i className="ri-check-line text-xl text-success"></i>
              </div>
              <div>
                <h3 className="text-lg font-bold text-primary mb-1">Analysis Complete!</h3>
                <p className="text-neutral-600 mb-3">
                  Your crop recommendations are ready for review. Check the detailed insights now.
                </p>
                <div className="flex gap-3">
                  <Link href="/crop-analysis?tab=crop-recommendation">
                    <Button 
                      className="bg-primary hover:bg-primary-dark"
                      onClick={onClose}
                    >
                      View Recommendations
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    onClick={onClose}
                  >
                    Dismiss
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}