import { cn } from "@/lib/utils";

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return (
    <div className={cn("animate-pulse rounded-md bg-neutral-200", className)} />
  );
}

export function CardSkeleton() {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-5 border-b border-neutral-100">
        <div className="flex items-center mb-3">
          <Skeleton className="h-10 w-10 rounded-lg mr-3" />
          <Skeleton className="h-5 w-40" />
        </div>
        <Skeleton className="h-4 w-full max-w-md" />
      </div>
      <div className="p-5">
        <Skeleton className="h-32 w-full mb-4" />
        <Skeleton className="h-10 w-full rounded-lg" />
      </div>
    </div>
  );
}

export function LandListingSkeleton() {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <Skeleton className="h-48 w-full" />
      <div className="p-4">
        <div className="flex justify-between items-center mb-3">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-24" />
        </div>
        <div className="flex space-x-2 mb-4">
          <Skeleton className="h-8 w-20 rounded-lg" />
          <Skeleton className="h-8 w-20 rounded-lg" />
          <Skeleton className="h-8 w-20 rounded-lg" />
        </div>
        <Skeleton className="h-10 w-full rounded-lg" />
      </div>
    </div>
  );
}

export function MarketPriceRowSkeleton() {
  return (
    <tr className="hover:bg-neutral-50 transition-all">
      <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
      <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
      <td className="px-6 py-4"><Skeleton className="h-4 w-16" /></td>
      <td className="px-6 py-4"><Skeleton className="h-4 w-24" /></td>
      <td className="px-6 py-4"><Skeleton className="h-4 w-28" /></td>
      <td className="px-6 py-4"><Skeleton className="h-4 w-20" /></td>
    </tr>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <>
      {Array(rows)
        .fill(0)
        .map((_, index) => (
          <MarketPriceRowSkeleton key={index} />
        ))}
    </>
  );
}

export function WeatherForecastSkeleton() {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-5 border-b border-neutral-100">
        <Skeleton className="h-6 w-40 mb-2" />
        <Skeleton className="h-4 w-60" />
      </div>
      <div className="p-5">
        <Skeleton className="h-24 w-full rounded-lg mb-4" />
        <div className="grid grid-cols-5 gap-1 mb-4">
          {Array(5)
            .fill(0)
            .map((_, index) => (
              <div key={index} className="flex flex-col items-center space-y-2">
                <Skeleton className="h-4 w-10" />
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-4 w-8" />
              </div>
            ))}
        </div>
        <Skeleton className="h-10 w-full rounded-lg" />
      </div>
    </div>
  );
}
