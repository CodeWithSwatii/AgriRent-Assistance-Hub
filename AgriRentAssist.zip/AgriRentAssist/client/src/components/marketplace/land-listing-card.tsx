import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { HoverScale } from "@/components/ui/animations";
import type { LandListing } from "@shared/schema";

interface LandListingCardProps {
  listing: LandListing;
  onViewDetails?: (id: number) => void;
}

const LandListingCard = ({ listing, onViewDetails }: LandListingCardProps) => {
  const { toast } = useToast();
  const [isFavorite, setIsFavorite] = useState(false);

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    toast({
      title: !isFavorite ? "Added to favorites" : "Removed from favorites",
      description: `${listing.title} has been ${!isFavorite ? "added to" : "removed from"} your favorites.`,
    });
  };

  const handleViewDetails = () => {
    if (onViewDetails) {
      onViewDetails(listing.id);
    }
  };

  // Helper to get badge style based on transaction type
  const getBadgeClass = () => {
    switch (listing.transactionType) {
      case "sale":
        return "bg-accent";
      case "lease":
        return "bg-primary";
      default:
        return "bg-primary";
    }
  };

  // Format price with transaction type
  const formatPrice = () => {
    if (listing.transactionType === "sale") {
      return <div className="font-heading font-bold text-xl text-neutral-800">₹{listing.price.toLocaleString()}</div>;
    } else {
      return (
        <div className="font-heading font-bold text-xl text-neutral-800">
          ₹{listing.price.toLocaleString()}
          <span className="text-sm font-normal text-neutral-500">/{listing.priceUnit}</span>
        </div>
      );
    }
  };

  // Format features from JSON object
  const renderFeatures = () => {
    const features = listing.features as Record<string, boolean | number | string>;
    const featureItems = [];

    if (features.irrigation) {
      featureItems.push({ icon: "ri-drop-line", label: "Irrigation" });
    }
    if (features.farmhouse) {
      featureItems.push({ icon: "ri-home-line", label: "Farmhouse" });
    }
    if (features.roadAccess) {
      featureItems.push({ icon: "ri-road-map-line", label: "Road Access" });
    }
    if (features.trees) {
      featureItems.push({ icon: "ri-plant-line", label: `${features.trees} Trees` });
    }
    if (features.storage) {
      featureItems.push({ icon: "ri-home-line", label: "Storage Facility" });
    }
    if (features.nearMarket) {
      featureItems.push({ icon: "ri-map-pin-line", label: "Near Market" });
    }

    return featureItems.slice(0, 3);
  };

  // Calculate how long ago the listing was created
  const getListingAge = () => {
    const now = new Date();
    const created = new Date(listing.createdAt);
    const diffInDays = Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) {
      return "Listed today";
    } else if (diffInDays === 1) {
      return "Listed yesterday";
    } else if (diffInDays < 7) {
      return `Listed ${diffInDays} days ago`;
    } else if (diffInDays < 30) {
      const weeks = Math.floor(diffInDays / 7);
      return `Listed ${weeks} ${weeks === 1 ? "week" : "weeks"} ago`;
    } else {
      const months = Math.floor(diffInDays / 30);
      return `Listed ${months} ${months === 1 ? "month" : "months"} ago`;
    }
  };

  const features = renderFeatures();

  return (
    <HoverScale scale={1.02} className="bg-white rounded-xl shadow-md overflow-hidden group">
      <div className="relative h-48">
        <img
          src={listing.images?.[0] || "https://placehold.co/600x400/e9e9e9/959595?text=No+Image"}
          className="w-full h-full object-cover transition-all group-hover:scale-105"
          alt={listing.title}
        />
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-black opacity-50"></div>
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="absolute top-4 left-4"
        >
          <span className={`${getBadgeClass()} text-white text-xs px-3 py-1 rounded-full`}>
            {listing.transactionType === "rent"
              ? "For Rent"
              : listing.transactionType === "sale"
              ? "For Sale"
              : "For Lease"}
          </span>
        </motion.div>
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="font-heading font-semibold text-white text-lg">{listing.title}</h3>
          <div className="flex items-center text-white text-sm">
            <i className="ri-map-pin-line mr-1"></i>
            <span>{listing.location}</span>
          </div>
        </div>
        <button
          className={`absolute top-4 right-4 bg-white bg-opacity-80 hover:bg-opacity-100 p-1.5 rounded-full ${
            isFavorite ? "text-accent" : "text-neutral-600 hover:text-accent"
          } transition-all`}
          onClick={handleFavorite}
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          <i className={isFavorite ? "ri-heart-fill" : "ri-heart-line"}></i>
        </button>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-center mb-3">
          {formatPrice()}
          <div className="text-sm text-neutral-500">{getListingAge()}</div>
        </div>
        <div className="flex flex-wrap gap-3 mb-4">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 * (index + 1) }}
              className="bg-neutral-100 rounded-lg px-3 py-1 flex items-center"
            >
              <i className={`${feature.icon} text-primary mr-1`}></i>
              <span className="text-xs">{feature.label}</span>
            </motion.div>
          ))}
        </div>
        <Button 
          variant="outline" 
          className="w-full hover:bg-primary hover:text-white"
          onClick={handleViewDetails}
        >
          View Details
        </Button>
      </div>
    </HoverScale>
  );
};

export default LandListingCard;
