import { useEffect, useRef, useState } from "react";
import { LandListing, EquipmentListing } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

// Import Leaflet
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";

// Fix Leaflet default icon issue
// @ts-ignore
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
});

interface LeafletMapProps {
  landListings?: LandListing[];
  equipmentListings?: EquipmentListing[];
  activeTab: "land" | "equipment";
  onSelectListing?: (id: number) => void;
}

// Create custom marker icons
const createCustomIcon = (color: string, borderColor: string) => {
  return L.divIcon({
    className: "custom-marker",
    html: `<div style="
      background-color: ${color}; 
      border: 2px solid ${borderColor};
      width: 12px; 
      height: 12px; 
      border-radius: 50%;
      box-shadow: 0 0 4px rgba(0,0,0,0.4);
    "></div>`,
    iconSize: [12, 12],
    iconAnchor: [6, 6],
  });
};

// Land and equipment icons
const landIcon = createCustomIcon("#2D7738", "#1E5128");
const equipmentIcon = createCustomIcon("#E3B448", "#C99A31");

// MapBounds component to dynamically fit the map to markers
function MapBounds({ listings }: { listings: (LandListing | EquipmentListing)[] }) {
  const map = useMap();
  
  useEffect(() => {
    if (listings.length === 0) return;
    
    // Create bounds from listings with coordinates
    const validListings = listings.filter(listing => 
      listing.latitude && listing.longitude
    );
    
    if (validListings.length === 0) return;
    
    const bounds = L.latLngBounds(
      validListings.map(listing => [listing.latitude!, listing.longitude!])
    );
    
    map.fitBounds(bounds, { padding: [50, 50] });
    
    // If there's only one valid listing, set a reasonable zoom
    if (validListings.length === 1) {
      setTimeout(() => {
        map.setZoom(13);
      }, 100);
    }
  }, [listings, map]);
  
  return null;
}

const LeafletMap = ({
  landListings = [],
  equipmentListings = [],
  activeTab,
  onSelectListing,
}: LeafletMapProps) => {
  const { toast } = useToast();
  
  // Determine which listings to display
  const listings = activeTab === "land" ? landListings : equipmentListings;
  
  // Default center (Pune, India)
  const defaultCenter: [number, number] = [18.5204, 73.8567];
  
  // Open in external map
  const openInExternalMap = () => {
    // Default to center of map
    let lat = defaultCenter[0];
    let lng = defaultCenter[1];
    
    // If we have listings with coordinates, use the first one
    const validListings = listings.filter(listing => 
      listing.latitude && listing.longitude
    );
    
    if (validListings.length > 0) {
      lat = validListings[0].latitude!;
      lng = validListings[0].longitude!;
    }
    
    // Open location in Google Maps
    window.open(`https://www.google.com/maps/search/?api=1&query=${lat},${lng}`, '_blank');
  };
  
  return (
    <div className="relative w-full h-64 md:h-80 rounded-xl overflow-hidden shadow-md">
      <MapContainer 
        center={defaultCenter} 
        zoom={10} 
        style={{ height: "100%", width: "100%" }}
        className="z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {listings.filter(listing => listing.latitude && listing.longitude).map((listing) => (
          <Marker 
            key={listing.id}
            position={[listing.latitude!, listing.longitude!]} 
            icon={activeTab === "land" ? landIcon : equipmentIcon}
          >
            <Popup>
              <div className="max-w-[200px]">
                <h3 className="font-bold text-sm">{listing.title}</h3>
                <p className="text-xs mt-1">{listing.location}</p>
                <p className="text-xs mt-1">₹{listing.price}/{listing.priceUnit}</p>
                <button 
                  className="mt-2 text-xs bg-primary text-white py-1 px-2 rounded-md hover:bg-primary-dark"
                  onClick={() => onSelectListing && onSelectListing(listing.id)}
                >
                  View Details
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
        
        <MapBounds listings={listings} />
      </MapContainer>
      
      <div className="absolute top-4 right-4 z-10 flex space-x-2">
        <Button 
          size="icon" 
          variant="outline" 
          className="bg-white shadow hover:shadow-md hover:bg-accent hover:text-white"
          onClick={openInExternalMap}
          title="Open in Google Maps"
        >
          <i className="ri-map-pin-fill text-primary"></i>
        </Button>
      </div>
    </div>
  );
};

export default LeafletMap;