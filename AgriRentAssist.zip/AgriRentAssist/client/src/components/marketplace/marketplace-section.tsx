import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import LandListingCard from "./land-listing-card";
import EquipmentListingCard from "./equipment-listing-card";
import LeafletMap from "./leaflet-map";
import { LandListingSkeleton } from "@/components/ui/loading-skeleton";
import { LAND_TRANSACTION_TYPES, LAND_TYPES, EQUIPMENT_TYPES, PRICE_RANGES } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { FadeIn, SlideUp } from "@/components/ui/animations";
import type { LandListing, EquipmentListing } from "@shared/schema";

interface MarketplaceSectionProps {
  viewAll?: boolean;
}

const MarketplaceSection = ({ viewAll = false }: MarketplaceSectionProps) => {
  const [tab, setTab] = useState<"land" | "equipment">("land");
  const [location, setLocation] = useState("");
  const [type, setType] = useState("all");
  const [priceRange, setPriceRange] = useState("any");
  const [transactionType, setTransactionType] = useState("all");
  
  const { toast } = useToast();
  
  // Land listings query
  const {
    isLoading: isLoadingLand,
    data: landListings,
  } = useQuery<LandListing[]>({
    queryKey: ["/api/land-listings"],
  });
  
  // Equipment listings query
  const {
    isLoading: isLoadingEquipment,
    data: equipmentListings,
  } = useQuery<EquipmentListing[]>({
    queryKey: ["/api/equipment-listings"],
  });
  
  const handleSearch = () => {
    toast({
      title: "Search Initiated",
      description: `Searching for ${tab} in ${location || "all locations"}`,
    });
    // In a real implementation, this would update query parameters and refetch the data
  };
  
  const handleViewDetails = (id: number) => {
    toast({
      title: "Viewing Details",
      description: `Opening details for listing #${id}`,
    });
    // In a real implementation, this would navigate to a details page
  };

  return (
    <section id="marketplace" className="mb-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row items-center justify-between mb-6"
      >
        <div>
          <h2 className="font-heading font-bold text-2xl text-neutral-800">
            Land & Equipment Marketplace
          </h2>
          <p className="text-neutral-600 mt-1">
            Find or list agricultural land and equipment for rent or sale
          </p>
        </div>
        <div className="mt-4 md:mt-0 space-x-2">
          <Button
            variant={tab === "land" ? "default" : "outline"}
            onClick={() => setTab("land")}
            className={tab === "land" ? "bg-primary text-white" : ""}
          >
            Land
          </Button>
          <Button
            variant={tab === "equipment" ? "default" : "outline"}
            onClick={() => setTab("equipment")}
            className={tab === "equipment" ? "bg-primary text-white" : ""}
          >
            Equipment
          </Button>
        </div>
      </motion.div>

      {/* Search and Filter */}
      <SlideUp className="bg-white rounded-xl shadow-md p-4 md:p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="col-span-1">
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Location
            </label>
            <div className="relative">
              <Input
                type="text"
                placeholder="Search location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="pl-10"
              />
              <i className="ri-map-pin-line absolute left-3 top-2.5 text-neutral-500"></i>
            </div>
          </div>
          <div className="col-span-1">
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Type
            </label>
            <Select value={type} onValueChange={setType}>
              <option value="all">All Types</option>
              {tab === "land" ? (
                LAND_TYPES.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))
              ) : (
                EQUIPMENT_TYPES.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))
              )}
            </Select>
          </div>
          <div className="col-span-1">
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Price Range
            </label>
            <Select value={priceRange} onValueChange={setPriceRange}>
              {PRICE_RANGES.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </Select>
          </div>
          <div className="col-span-1">
            <label className="block text-sm font-medium text-neutral-700 mb-1">
              Transaction
            </label>
            <Select value={transactionType} onValueChange={setTransactionType}>
              <option value="all">All</option>
              {LAND_TRANSACTION_TYPES.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </Select>
          </div>
        </div>
        <div className="flex justify-end mt-4">
          <Button className="bg-primary hover:bg-primary-dark" onClick={handleSearch}>
            <i className="ri-search-line mr-1"></i> Search
          </Button>
        </div>
      </SlideUp>

      {/* Map View */}
      <FadeIn className="mb-6">
        <LeafletMap
          landListings={landListings || []}
          equipmentListings={equipmentListings || []}
          activeTab={tab}
          onSelectListing={handleViewDetails}
        />
      </FadeIn>

      {/* Listings */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {tab === "land" ? (
          isLoadingLand ? (
            Array(3)
              .fill(0)
              .map((_, i) => <LandListingSkeleton key={i} />)
          ) : landListings && landListings.length > 0 ? (
            landListings
              .slice(0, viewAll ? undefined : 3)
              .map((listing) => (
                <LandListingCard
                  key={listing.id}
                  listing={listing}
                  onViewDetails={handleViewDetails}
                />
              ))
          ) : (
            <div className="col-span-full text-center py-10">
              <i className="ri-emotion-sad-line text-3xl text-neutral-400"></i>
              <p className="mt-2 text-neutral-600">No land listings found</p>
            </div>
          )
        ) : isLoadingEquipment ? (
          Array(3)
            .fill(0)
            .map((_, i) => <LandListingSkeleton key={i} />)
        ) : equipmentListings && equipmentListings.length > 0 ? (
          equipmentListings
            .slice(0, viewAll ? undefined : 3)
            .map((listing) => (
              <EquipmentListingCard
                key={listing.id}
                listing={listing}
                onViewDetails={handleViewDetails}
              />
            ))
        ) : (
          <div className="col-span-full text-center py-10">
            <i className="ri-emotion-sad-line text-3xl text-neutral-400"></i>
            <p className="mt-2 text-neutral-600">No equipment listings found</p>
          </div>
        )}
      </div>

      {!viewAll && (
        <div className="text-center">
          <Link href="/marketplace">
            <Button variant="outline" className="bg-white hover:bg-neutral-100 text-primary">
              View More Listings <i className="ri-arrow-right-line ml-1"></i>
            </Button>
          </Link>
        </div>
      )}
    </section>
  );
};

export default MarketplaceSection;
