import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Select } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import { FadeIn, ScaleIn } from "@/components/ui/animations";
import { MARKETS } from "@/lib/constants";
import type { MarketPrice } from "@shared/schema";

interface MarketPricesSectionProps {
  viewAll?: boolean;
}

const MarketPricesSection = ({ viewAll = false }: MarketPricesSectionProps) => {
  const [selectedMarket, setSelectedMarket] = useState("Maharashtra");

  const {
    isLoading,
    data: marketPrices,
  } = useQuery<MarketPrice[]>({
    queryKey: ["/api/market-prices"],
  });

  return (
    <section id="market-prices" className="mb-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row items-center justify-between mb-6"
      >
        <div>
          <h2 className="font-heading font-bold text-2xl text-neutral-800">
            Live Market Prices
          </h2>
          <p className="text-neutral-600 mt-1">Real-time crop prices from major markets</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Select value={selectedMarket} onValueChange={setSelectedMarket}>
            {MARKETS.map((market) => (
              <option key={market} value={market}>
                {market}
              </option>
            ))}
          </Select>
        </div>
      </motion.div>

      <ScaleIn className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-neutral-100">
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Crop</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Market</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Variety</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">
                  Price (₹/Quintal)
                </th>
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Change</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {isLoading ? (
                <TableSkeleton rows={5} />
              ) : marketPrices && marketPrices.length > 0 ? (
                marketPrices.slice(0, viewAll ? undefined : 5).map((price) => {
                  const priceChange = price.price - (price.previousPrice || price.price);
                  const changePercent = price.previousPrice
                    ? ((priceChange / price.previousPrice) * 100).toFixed(2)
                    : "0.00";
                  const isPositive = priceChange >= 0;

                  // Calculate the time difference
                  const now = new Date();
                  const updated = new Date(price.updatedAt);
                  const diffMs = now.getTime() - updated.getTime();
                  const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                  const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                  
                  let updatedText = "";
                  if (diffHrs > 0) {
                    updatedText = `${diffHrs} ${diffHrs === 1 ? "hour" : "hours"} ago`;
                  } else {
                    updatedText = `${diffMins} ${diffMins === 1 ? "minute" : "minutes"} ago`;
                  }

                  return (
                    <motion.tr
                      key={price.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                      className="hover:bg-neutral-50 transition-all"
                    >
                      <td className="px-6 py-4 text-sm text-neutral-700">{price.crop}</td>
                      <td className="px-6 py-4 text-sm text-neutral-600">{price.market}</td>
                      <td className="px-6 py-4 text-sm text-neutral-600">{price.variety || "Standard"}</td>
                      <td className="px-6 py-4 text-sm font-medium text-neutral-800">
                        ₹{price.price.toLocaleString()}
                      </td>
                      <td className="px-6 py-4">
                        <div
                          className={`inline-flex items-center ${
                            isPositive ? "text-success" : "text-error"
                          }`}
                        >
                          <i
                            className={`${
                              isPositive ? "ri-arrow-up-line" : "ri-arrow-down-line"
                            } mr-1`}
                          ></i>
                          <span className="text-sm font-medium">
                            ₹{Math.abs(priceChange)} ({Math.abs(parseFloat(changePercent))}%)
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-neutral-500">{updatedText}</td>
                    </motion.tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center">
                    <div className="flex flex-col items-center">
                      <i className="ri-emotion-sad-line text-3xl text-neutral-400"></i>
                      <p className="mt-2 text-neutral-600">No market prices available</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {!viewAll && (
          <div className="flex justify-end bg-neutral-50 px-6 py-3">
            <Link href="/market-prices">
              <button className="text-primary hover:text-primary-dark font-medium flex items-center transition-all">
                <span>View All Prices</span>
                <i className="ri-arrow-right-line ml-1"></i>
              </button>
            </Link>
          </div>
        )}
      </ScaleIn>
    </section>
  );
};

export default MarketPricesSection;
