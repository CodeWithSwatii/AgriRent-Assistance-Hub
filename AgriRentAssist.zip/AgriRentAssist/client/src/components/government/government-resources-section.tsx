import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { StaggerChildren, StaggerItem } from "@/components/ui/animations";
import { useToast } from "@/hooks/use-toast";
import type { GovernmentScheme } from "@shared/schema";

interface GovernmentResourcesSectionProps {
  limit?: number;
}

const GovernmentResourcesSection = ({ limit = 3 }: GovernmentResourcesSectionProps) => {
  const { toast } = useToast();
  
  const {
    isLoading,
    data: schemes,
  } = useQuery<GovernmentScheme[]>({
    queryKey: ["/api/government-schemes"],
  });

  const handleApply = (schemeId: number, schemeTitle: string) => {
    toast({
      title: "Application Started",
      description: `You are applying for "${schemeTitle}"`,
    });
    // In a real implementation, this would navigate to an application page or form
  };

  const handleViewDetails = (schemeId: number) => {
    toast({
      title: "Viewing Details",
      description: "Opening scheme details",
    });
    // In a real implementation, this would navigate to a detailed view
  };

  return (
    <section className="mb-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row items-center justify-between mb-6"
      >
        <div>
          <h2 className="font-heading font-bold text-2xl text-neutral-800">
            Government Assistance & Subsidies
          </h2>
          <p className="text-neutral-600 mt-1">Latest schemes and programs for farmers</p>
        </div>
      </motion.div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array(limit)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="bg-accent bg-opacity-10 p-4 border-b border-neutral-100">
                  <div className="skeleton h-6 w-48 mb-2"></div>
                  <div className="skeleton h-4 w-full"></div>
                </div>
                <div className="p-4">
                  <div className="mb-4">
                    <div className="flex items-center mb-2">
                      <div className="skeleton h-5 w-5 mr-2 rounded-full"></div>
                      <div className="skeleton h-4 w-40"></div>
                    </div>
                    <div className="flex items-center">
                      <div className="skeleton h-5 w-5 mr-2 rounded-full"></div>
                      <div className="skeleton h-4 w-56"></div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <div className="skeleton h-10 w-full rounded-lg"></div>
                    <div className="skeleton h-10 w-full rounded-lg"></div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      ) : (
        <StaggerChildren className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {schemes && schemes.length > 0 ? (
            schemes.slice(0, limit).map((scheme) => {
              // Format deadline if exists
              const deadlineText = scheme.deadline 
                ? new Date(scheme.deadline).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })
                : "Ongoing";

              return (
                <StaggerItem key={scheme.id}>
                  <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all overflow-hidden">
                    <div className="bg-accent bg-opacity-10 p-4 border-b border-neutral-100">
                      <h3 className="font-heading font-semibold text-lg text-neutral-800">
                        {scheme.title}
                      </h3>
                      <p className="text-sm text-neutral-600 mt-1">{scheme.description}</p>
                    </div>
                    <div className="p-4">
                      <div className="mb-4">
                        <div className="flex items-center mb-2">
                          <i className="ri-calendar-line text-primary mr-2"></i>
                          <span className="text-sm font-medium text-neutral-700">
                            Application Deadline:
                          </span>
                          <span className="text-sm text-neutral-600 ml-2">{deadlineText}</span>
                        </div>
                        <div className="flex items-center">
                          <i className="ri-government-line text-primary mr-2"></i>
                          <span className="text-sm font-medium text-neutral-700">Department:</span>
                          <span className="text-sm text-neutral-600 ml-2">{scheme.department}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          className="flex-1 hover:bg-primary hover:text-white"
                          onClick={() => handleViewDetails(scheme.id)}
                        >
                          Details
                        </Button>
                        <Button
                          className="flex-1 bg-accent hover:bg-accent-dark text-neutral-800"
                          onClick={() => handleApply(scheme.id, scheme.title)}
                        >
                          Apply Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </StaggerItem>
              );
            })
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center py-12 bg-white rounded-xl shadow-md">
              <i className="ri-file-search-line text-4xl text-neutral-400 mb-3"></i>
              <h3 className="font-heading font-medium text-lg text-neutral-700 mb-1">
                No Schemes Available
              </h3>
              <p className="text-neutral-500">
                There are no government schemes available at the moment.
              </p>
            </div>
          )}
        </StaggerChildren>
      )}
    </section>
  );
};

export default GovernmentResourcesSection;
