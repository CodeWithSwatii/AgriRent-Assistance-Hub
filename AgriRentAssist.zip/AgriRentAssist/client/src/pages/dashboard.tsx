import { useState } from "react";
import { PageTransition, FadeIn, SlideUp } from "@/components/ui/animations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/loading-skeleton";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { insertLandListingSchema } from "@shared/schema";
import { LAND_TRANSACTION_TYPES, LAND_TYPES } from "@/lib/constants";
import { z } from "zod";
import type { User, SoilAnalysis, LandListing, EquipmentListing, InsertLandListing, InsertSoilAnalysis, InsertCropRecommendation } from "@shared/schema";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [showOptionDialog, setShowOptionDialog] = useState(false);
  const [showAddListingDialog, setShowAddListingDialog] = useState(false);
  const [showEditLandDialog, setShowEditLandDialog] = useState(false);
  const [showSoilAnalysisForm, setShowSoilAnalysisForm] = useState(false);
  const [showCropRecommendationForm, setShowCropRecommendationForm] = useState(false);
  const [showLandRentalForm, setShowLandRentalForm] = useState(false);
  const [currentLandListing, setCurrentLandListing] = useState<LandListing | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<any[]>([]);
  const { toast } = useToast();

  // Create a mock user instead of relying on authentication
  const mockUser = { id: 1, fullName: "User", username: "user", role: "user" };
  const isLoadingAuthUser = false;
  
  // Fetch user data
  const { data: userData, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: ["/api/user"],
    enabled: false, // Using mockUser directly instead
  });

  // Fetch soil analyses
  const { data: soilAnalyses, isLoading: isLoadingSoil } = useQuery<SoilAnalysis[]>({
    queryKey: ["/api/soil-analyses?userId=1"],
  });

  // Fetch user's land listings
  const { data: userLandListings, isLoading: isLoadingLand } = useQuery<LandListing[]>({
    queryKey: ["/api/land-listings"],
  });

  // Fetch user's equipment listings
  const { data: userEquipmentListings, isLoading: isLoadingEquipment } = useQuery<EquipmentListing[]>({
    queryKey: ["/api/equipment-listings"],
  });

  // Create land listing mutation
  const createLandListingMutation = useMutation({
    mutationFn: async (data: InsertLandListing) => {
      const response = await apiRequest("POST", "/api/land-listings", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Land listing created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/land-listings"] });
      setShowAddListingDialog(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create land listing: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update land listing mutation
  const updateLandListingMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertLandListing> }) => {
      const response = await apiRequest("PUT", `/api/land-listings/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Land listing updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/land-listings"] });
      setShowEditLandDialog(false);
      setCurrentLandListing(null);
      editForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update land listing: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form definition for land listing creation
  const landListingSchema = insertLandListingSchema.extend({
    // Additional client-side validation
    size: z.coerce.number().min(1, "Size must be at least 1 acre"),
    price: z.coerce.number().min(1, "Price must be greater than 0"),
  });

  const form = useForm<z.infer<typeof landListingSchema>>({
    resolver: zodResolver(landListingSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      size: 0,
      price: 0,
      priceUnit: "per acre/month",
      transactionType: "rent",
      features: {
        soilType: "",
        waterSource: "",
        irrigation: false,
        connectivity: false,
      },
      userId: userData?.id || 1,
      available: true,
    },
  });

  const editForm = useForm<z.infer<typeof landListingSchema>>({
    resolver: zodResolver(landListingSchema),
    defaultValues: {
      title: "",
      description: "",
      location: "",
      size: 0,
      price: 0,
      priceUnit: "per acre/month",
      transactionType: "rent",
      features: {
        soilType: "",
        waterSource: "",
        irrigation: false,
        connectivity: false,
      },
      userId: userData?.id || 1,
      available: true,
    },
  });

  // Form submission handler for adding land listing
  function onAddLandSubmit(values: z.infer<typeof landListingSchema>) {
    const features = values.features || {};
    createLandListingMutation.mutate({
      ...values,
      userId: userData?.id || 1,
      features: {
        ...features,
        irrigation: Boolean(features.irrigation),
        connectivity: Boolean(features.connectivity),
      },
    });
  }

  // Form submission handler for editing land listing
  function onEditLandSubmit(values: z.infer<typeof landListingSchema>) {
    if (currentLandListing) {
      const features = values.features || {};
      updateLandListingMutation.mutate({
        id: currentLandListing.id,
        data: {
          ...values,
          features: {
            ...features,
            irrigation: Boolean(features.irrigation),
            connectivity: Boolean(features.connectivity),
          },
        },
      });
    }
  }

  // Handle opening the options dialog
  const handleAddListing = () => {
    setSelectedOption(null);
    setShowOptionDialog(true);
  };
  
  // Handle option selection
  const handleOptionSelect = (option: string) => {
    setSelectedOption(option);
    
    if (option === "land") {
      setShowLandRentalForm(true);
    } else if (option === "soil") {
      setShowSoilAnalysisForm(true);
    } else if (option === "crop") {
      setShowCropRecommendationForm(true);
    }
    
    setShowOptionDialog(false);
  };

  // Handle editing a land listing
  const handleEditLand = (listing: LandListing) => {
    setCurrentLandListing(listing);
    editForm.reset({
      title: listing.title,
      description: listing.description,
      location: listing.location,
      size: listing.size,
      price: listing.price,
      priceUnit: listing.priceUnit,
      transactionType: listing.transactionType,
      features: listing.features as any,
      userId: listing.userId,
      available: listing.available,
    });
    setShowEditLandDialog(true);
  };

  // Mock data for visualizations
  const cropYieldData = [
    { name: "Jan", yield: 65 },
    { name: "Feb", yield: 75 },
    { name: "Mar", yield: 85 },
    { name: "Apr", yield: 90 },
    { name: "May", yield: 100 },
    { name: "Jun", yield: 110 },
    { name: "Jul", yield: 120 },
    { name: "Aug", yield: 130 },
    { name: "Sep", yield: 135 },
    { name: "Oct", yield: 140 },
    { name: "Nov", yield: 130 },
    { name: "Dec", yield: 120 },
  ];

  const revenueData = [
    { name: "Land Lease", value: 25000 },
    { name: "Equipment Rental", value: 15000 },
    { name: "Crop Sales", value: 45000 },
    { name: "Subsidies", value: 10000 },
  ];

  const COLORS = ["#2D7738", "#8B5A2B", "#E3B448", "#4CAF50"];

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <FadeIn>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h1 className="font-heading font-bold text-3xl text-neutral-800">Dashboard</h1>
              <p className="text-neutral-600 mt-1">
                Welcome back, {isLoadingAuthUser ? "..." : mockUser.fullName}
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button className="bg-primary hover:bg-primary-dark" onClick={handleAddListing}>
                <i className="ri-add-line mr-1"></i> Add New Listing
              </Button>
            </div>
          </div>
        </FadeIn>

        <SlideUp>
          <Tabs defaultValue="overview" className="mb-8" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="listings">My Listings</TabsTrigger>
              <TabsTrigger value="analytics">Soil Analytics</TabsTrigger>
              <TabsTrigger value="transactions">Transactions</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-500">
                      Active Listings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingLand || isLoadingEquipment ? (
                        <Skeleton className="h-8 w-16" />
                      ) : (
                        (userLandListings?.length || 0) + (userEquipmentListings?.length || 0)
                      )}
                    </div>
                    <p className="text-xs text-success flex items-center mt-1">
                      <i className="ri-arrow-up-line mr-1"></i>
                      <span>12% increase</span>
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-500">
                      Soil Health Score
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {isLoadingSoil ? (
                        <Skeleton className="h-8 w-16" />
                      ) : soilAnalyses && soilAnalyses.length > 0 ? (
                        soilAnalyses[0].soilHealthScore
                      ) : (
                        "N/A"
                      )}
                    </div>
                    <p className="text-xs text-success flex items-center mt-1">
                      <i className="ri-arrow-up-line mr-1"></i>
                      <span>5 points</span>
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-500">
                      Total Revenue
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">₹95,000</div>
                    <p className="text-xs text-success flex items-center mt-1">
                      <i className="ri-arrow-up-line mr-1"></i>
                      <span>8% increase</span>
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-500">
                      Applied Schemes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">3</div>
                    <p className="text-xs text-neutral-500 flex items-center mt-1">
                      <span>2 pending approval</span>
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Crop Yield Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={cropYieldData}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="colorYield" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#2D7738" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="#2D7738" stopOpacity={0.1} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Area
                            type="monotone"
                            dataKey="yield"
                            stroke="#2D7738"
                            fillOpacity={1}
                            fill="url(#colorYield)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={revenueData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {revenueData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="listings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>My Land Listings</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoadingLand ? (
                    <div className="space-y-4">
                      {Array(3)
                        .fill(0)
                        .map((_, i) => (
                          <Skeleton key={i} className="h-20 w-full" />
                        ))}
                    </div>
                  ) : userLandListings && userLandListings.length > 0 ? (
                    <div className="space-y-4">
                      {userLandListings.map((listing) => (
                        <div
                          key={listing.id}
                          className="bg-neutral-50 p-4 rounded-lg flex justify-between items-center"
                        >
                          <div>
                            <h3 className="font-medium text-neutral-800">{listing.title}</h3>
                            <p className="text-sm text-neutral-600">
                              {listing.location} • {listing.size} acres
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                listing.available
                                  ? "bg-success bg-opacity-20 text-success"
                                  : "bg-neutral-200 text-neutral-600"
                              }`}
                            >
                              {listing.available ? "Available" : "Unavailable"}
                            </span>
                            <Button variant="outline" size="sm" onClick={() => handleEditLand(listing)}>
                              Edit
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <i className="ri-file-list-3-line text-3xl text-neutral-400 mb-2"></i>
                      <p className="text-neutral-600">No land listings found</p>
                      <Button className="mt-4 bg-primary hover:bg-primary-dark" onClick={handleAddListing}>
                        Add Land Listing
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My Equipment Listings</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoadingEquipment ? (
                    <div className="space-y-4">
                      {Array(2)
                        .fill(0)
                        .map((_, i) => (
                          <Skeleton key={i} className="h-20 w-full" />
                        ))}
                    </div>
                  ) : userEquipmentListings && userEquipmentListings.length > 0 ? (
                    <div className="space-y-4">
                      {userEquipmentListings.map((listing) => (
                        <div
                          key={listing.id}
                          className="bg-neutral-50 p-4 rounded-lg flex justify-between items-center"
                        >
                          <div>
                            <h3 className="font-medium text-neutral-800">{listing.title}</h3>
                            <p className="text-sm text-neutral-600">
                              {listing.location} • ₹{listing.price}/{listing.priceUnit}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                listing.available
                                  ? "bg-success bg-opacity-20 text-success"
                                  : "bg-neutral-200 text-neutral-600"
                              }`}
                            >
                              {listing.available ? "Available" : "Unavailable"}
                            </span>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <i className="ri-tools-line text-3xl text-neutral-400 mb-2"></i>
                      <p className="text-neutral-600">No equipment listings found</p>
                      <Button className="mt-4 bg-primary hover:bg-primary-dark">
                        Add Equipment Listing
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Soil Health Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoadingSoil ? (
                    <div className="space-y-4">
                      <Skeleton className="h-40 w-full" />
                      <div className="grid grid-cols-3 gap-4">
                        <Skeleton className="h-20 w-full" />
                        <Skeleton className="h-20 w-full" />
                        <Skeleton className="h-20 w-full" />
                      </div>
                    </div>
                  ) : soilAnalyses && soilAnalyses.length > 0 ? (
                    <div>
                      <div className="mb-6">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="font-medium">Recent Analysis</h3>
                          <span className="text-sm text-neutral-500">
                            {soilAnalyses[0].date ? new Date(soilAnalyses[0].date).toLocaleDateString() : 'N/A'}
                          </span>
                        </div>
                        
                        <div className="h-60">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={[
                                { name: "Nitrogen", value: soilAnalyses[0].nitrogen || 0 },
                                { name: "Phosphorus", value: soilAnalyses[0].phosphorus || 0 },
                                { name: "Potassium", value: soilAnalyses[0].potassium || 0 },
                                { name: "Organic Matter", value: (soilAnalyses[0].organicMatter || 0) * 10 },
                                { name: "pH", value: (soilAnalyses[0].pHLevel || 0) * 10 },
                              ]}
                              margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip />
                              <Bar
                                dataKey="value"
                                fill="#2D7738"
                                background={{ fill: "#eee" }}
                                animationDuration={1000}
                              />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-neutral-50 p-4 rounded-lg">
                          <div className="text-sm text-neutral-600 mb-1">Soil Health Score</div>
                          <div className="text-2xl font-bold text-primary">
                            {soilAnalyses[0].soilHealthScore}
                            <span className="text-xs font-normal text-success ml-2">
                              Good
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-neutral-50 p-4 rounded-lg">
                          <div className="text-sm text-neutral-600 mb-1">pH Level</div>
                          <div className="text-2xl font-bold text-primary">
                            {soilAnalyses[0].pHLevel}
                            <span className="text-xs font-normal text-neutral-600 ml-2">
                              {soilAnalyses[0].pHLevel && soilAnalyses[0].pHLevel < 6.5 
                                ? "Acidic" 
                                : soilAnalyses[0].pHLevel && soilAnalyses[0].pHLevel > 7.5 
                                ? "Alkaline" 
                                : "Neutral"}
                            </span>
                          </div>
                        </div>
                        
                        <div className="bg-neutral-50 p-4 rounded-lg">
                          <div className="text-sm text-neutral-600 mb-1">Recommended Action</div>
                          <div className="text-base font-medium text-neutral-800">
                            {soilAnalyses[0].recommendations 
                              ? (soilAnalyses[0].recommendations as any).fertilizer 
                              : "No specific recommendation"}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <i className="ri-flask-line text-3xl text-neutral-400 mb-2"></i>
                      <p className="text-neutral-600">No soil analysis data found</p>
                      <Button className="mt-4 bg-primary hover:bg-primary-dark">
                        Upload Soil Report
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="transactions" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-16">
                    <i className="ri-exchange-funds-line text-4xl text-neutral-400 mb-2"></i>
                    <p className="text-neutral-600 font-medium mb-2">No transaction data yet</p>
                    <p className="text-neutral-500 max-w-md mx-auto mb-4">
                      When you rent, buy, or sell land and equipment, your transactions will appear here.
                    </p>
                    <Button className="bg-primary hover:bg-primary-dark">
                      Explore Marketplace
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </SlideUp>
      </div>
      {/* Options Dialog */}
      <Dialog open={showOptionDialog} onOpenChange={setShowOptionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>What would you like to add?</DialogTitle>
            <DialogDescription>
              Select the type of information you'd like to add to your account.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 gap-4 py-4">
            <Button 
              className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-800 border border-green-200" 
              variant="outline"
              onClick={() => handleOptionSelect("land")}
            >
              <i className="ri-landscape-line text-2xl"></i>
              <div className="text-sm font-medium">Land Details</div>
              <div className="text-xs text-center text-green-700">Add land rental details</div>
            </Button>
            
            <Button 
              className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200" 
              variant="outline"
              onClick={() => handleOptionSelect("soil")}
            >
              <i className="ri-seedling-line text-2xl"></i>
              <div className="text-sm font-medium">Soil Analysis</div>
              <div className="text-xs text-center text-amber-700">Add land type & soil details</div>
            </Button>
            
            <Button 
              className="w-full h-24 flex flex-col items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200" 
              variant="outline"
              onClick={() => handleOptionSelect("crop")}
            >
              <i className="ri-plant-line text-2xl"></i>
              <div className="text-sm font-medium">Crop Details</div>
              <div className="text-xs text-center text-blue-700">Add details for fertilizer recommendations</div>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Soil Analysis Form Dialog */}
      <Dialog open={showSoilAnalysisForm} onOpenChange={setShowSoilAnalysisForm}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Soil Analysis</DialogTitle>
            <DialogDescription>
              Enter details about your land and soil for better recommendations.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">Location</div>
                <Input id="location" placeholder="e.g., Pune, Maharashtra" />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Soil Type</div>
                <select id="soil-type" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                  <option value="">Select type</option>
                  <option value="clay">Clay Soil</option>
                  <option value="sandy">Sandy Soil</option>
                  <option value="loamy">Loamy Soil</option>
                  <option value="silty">Silty Soil</option>
                  <option value="peaty">Peaty Soil</option>
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">pH Level (if known)</div>
              <Input id="ph-level" type="number" placeholder="e.g., 6.5" min="0" max="14" step="0.1" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">Nitrogen (N)</div>
                <Input id="nitrogen" type="number" placeholder="mg/kg" />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Phosphorus (P)</div>
                <Input id="phosphorus" type="number" placeholder="mg/kg" />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Potassium (K)</div>
                <Input id="potassium" type="number" placeholder="mg/kg" />
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">Additional Notes</div>
              <Textarea id="notes" placeholder="Any other observations about your soil..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSoilAnalysisForm(false)}>Cancel</Button>
            <Button onClick={() => {
              const newData = {
                type: "soil",
                date: new Date().toISOString(),
                location: (document.getElementById("location") as HTMLInputElement).value,
                soilType: (document.getElementById("soil-type") as HTMLSelectElement).value,
                ph: (document.getElementById("ph-level") as HTMLInputElement).value,
                nitrogen: (document.getElementById("nitrogen") as HTMLInputElement).value,
                phosphorus: (document.getElementById("phosphorus") as HTMLInputElement).value,
                potassium: (document.getElementById("potassium") as HTMLInputElement).value,
                notes: (document.getElementById("notes") as HTMLTextAreaElement).value,
              };
              setSubmittedData([...submittedData, newData]);
              setShowSoilAnalysisForm(false);
              toast({
                title: "Success",
                description: "Soil analysis data has been saved",
              });
            }}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Crop Recommendation Form Dialog */}
      <Dialog open={showCropRecommendationForm} onOpenChange={setShowCropRecommendationForm}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Crop Details</DialogTitle>
            <DialogDescription>
              Enter details about your crops for fertilizer recommendations.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="text-sm font-medium">Crop Type</div>
              <select id="crop-type" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                <option value="">Select crop</option>
                <option value="rice">Rice</option>
                <option value="wheat">Wheat</option>
                <option value="sugarcane">Sugarcane</option>
                <option value="cotton">Cotton</option>
                <option value="maize">Maize</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-sm font-medium">Area (Acres)</div>
                <Input id="crop-area" type="number" placeholder="e.g., 5" min="0.1" step="0.1" />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Growing Season</div>
                <select id="crop-season" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                  <option value="">Select season</option>
                  <option value="kharif">Kharif (Monsoon)</option>
                  <option value="rabi">Rabi (Winter)</option>
                  <option value="zaid">Zaid (Summer)</option>
                  <option value="year-round">Year-round</option>
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">Irrigation Method</div>
              <select id="irrigation-method" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                <option value="">Select method</option>
                <option value="drip">Drip Irrigation</option>
                <option value="sprinkler">Sprinkler System</option>
                <option value="flood">Flood Irrigation</option>
                <option value="rainfed">Rainfed (No irrigation)</option>
              </select>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">Current Issues (if any)</div>
              <Textarea id="current-issues" placeholder="Describe any crop issues you're facing..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCropRecommendationForm(false)}>Cancel</Button>
            <Button onClick={() => {
              const newData = {
                type: "crop",
                date: new Date().toISOString(),
                cropType: (document.getElementById("crop-type") as HTMLSelectElement).value,
                area: (document.getElementById("crop-area") as HTMLInputElement).value,
                season: (document.getElementById("crop-season") as HTMLSelectElement).value,
                irrigation: (document.getElementById("irrigation-method") as HTMLSelectElement).value,
                issues: (document.getElementById("current-issues") as HTMLTextAreaElement).value,
              };
              setSubmittedData([...submittedData, newData]);
              setShowCropRecommendationForm(false);
              toast({
                title: "Success",
                description: "Crop details have been saved",
              });
            }}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Submitted Data Display */}
      {submittedData.length > 0 && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Recently Submitted Data</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {submittedData.map((data, index) => (
                <div key={index} className="bg-neutral-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-neutral-800">
                      {data.type === "soil" ? "Soil Analysis" : data.type === "crop" ? "Crop Details" : "Land Listing"}
                    </h3>
                    <span className="text-sm text-neutral-500">
                      {new Date(data.date).toLocaleString()}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {Object.entries(data).filter(([key]) => !["type", "date"].includes(key)).map(([key, value]) => (
                      <div key={key} className="flex">
                        <span className="font-medium mr-2">{key.charAt(0).toUpperCase() + key.slice(1)}:</span>
                        <span>{value as string}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Land Rental Form Dialog */}
      <Dialog open={showLandRentalForm} onOpenChange={setShowLandRentalForm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Land Rental Listing</DialogTitle>
            <DialogDescription>
              Enter details about your land for rental or leasing.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="basic">Basic Details</TabsTrigger>
              <TabsTrigger value="additional">Additional Info</TabsTrigger>
            </TabsList>
            <TabsContent value="basic" className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Listing Title</div>
                  <Input id="title" placeholder="E.g., Fertile Farm Land for Lease" />
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Area (Acres)</div>
                  <Input id="area" type="number" min="0.1" step="0.1" placeholder="E.g., 5.5" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Location</div>
                <Input id="location" placeholder="E.g., Nashik, Maharashtra" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Price (₹ per month/acre)</div>
                  <Input id="price" type="number" placeholder="E.g., 5000" />
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Rental Type</div>
                  <select id="rental-type" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option value="">Select type</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                    <option value="seasonal">Seasonal</option>
                    <option value="crop-share">Crop Share</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Description</div>
                <Textarea id="description" placeholder="Describe your land, soil quality, water availability, etc." />
              </div>
            </TabsContent>
            <TabsContent value="additional" className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Soil Type</div>
                  <select id="soil-type-land" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option value="">Select type</option>
                    <option value="clay">Clay Soil</option>
                    <option value="sandy">Sandy Soil</option>
                    <option value="loamy">Loamy Soil</option>
                    <option value="silty">Silty Soil</option>
                    <option value="peaty">Peaty Soil</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Irrigation</div>
                  <select id="irrigation-land" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                    <option value="">Select type</option>
                    <option value="borewell">Borewell</option>
                    <option value="canal">Canal</option>
                    <option value="river">River</option>
                    <option value="rainfed">Rainfed Only</option>
                    <option value="multiple">Multiple Sources</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Road Connectivity</div>
                <select id="connectivity-land" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                  <option value="">Select option</option>
                  <option value="excellent">Excellent (Highway adjacent)</option>
                  <option value="good">Good (Paved road access)</option>
                  <option value="average">Average (Village road)</option>
                  <option value="poor">Poor (Unpaved road)</option>
                  <option value="none">None (No direct road)</option>
                </select>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Lease Terms</div>
                <Textarea id="lease-terms" placeholder="Any specific lease terms or conditions..." />
              </div>
              <div className="space-y-2">
                <div className="text-sm font-medium">Available Equipment</div>
                <Textarea id="equipment" placeholder="List any farm equipment included in the rental..." />
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLandRentalForm(false)}>Cancel</Button>
            <Button onClick={() => {
              const newData = {
                type: "land",
                date: new Date().toISOString(),
                title: (document.getElementById("title") as HTMLInputElement)?.value || "",
                area: (document.getElementById("area") as HTMLInputElement)?.value || "",
                location: (document.getElementById("location") as HTMLInputElement)?.value || "",
                price: (document.getElementById("price") as HTMLInputElement)?.value || "",
                rentalType: (document.getElementById("rental-type") as HTMLSelectElement)?.value || "",
                description: (document.getElementById("description") as HTMLTextAreaElement)?.value || "",
                soilType: (document.getElementById("soil-type-land") as HTMLSelectElement)?.value || "",
                irrigation: (document.getElementById("irrigation-land") as HTMLSelectElement)?.value || "",
                connectivity: (document.getElementById("connectivity-land") as HTMLSelectElement)?.value || "",
                leaseTerms: (document.getElementById("lease-terms") as HTMLTextAreaElement)?.value || "",
                equipment: (document.getElementById("equipment") as HTMLTextAreaElement)?.value || "",
              };
              setSubmittedData([...submittedData, newData]);
              setShowLandRentalForm(false);
              toast({
                title: "Success",
                description: "Land rental listing has been saved",
              });
            }}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageTransition>
  );
};

export default Dashboard;
