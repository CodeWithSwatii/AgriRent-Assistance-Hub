import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { PageTransition, FadeIn, SlideUp } from "@/components/ui/animations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/loading-skeleton";
import { DAYS_OF_WEEK, WEATHER_ICONS } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line } from 'recharts';
import type { WeatherForecast } from "@shared/schema";

const Weather = () => {
  const { toast } = useToast();
  const [location, setLocation] = useState("Pune, Maharashtra");
  const [isSearching, setIsSearching] = useState(false);
  
  // Fetch weather forecasts
  const {
    isLoading,
    data: weatherForecasts,
    refetch
  } = useQuery<WeatherForecast[]>({
    queryKey: [`/api/weather-forecasts?location=${encodeURIComponent(location)}`],
  });
  
  const handleSearch = () => {
    if (!location.trim()) {
      toast({
        title: "Error",
        description: "Please enter a location to search",
        variant: "destructive",
      });
      return;
    }
    
    setIsSearching(true);
    // In a real implementation, this would update the query parameter and refetch
    setTimeout(() => {
      refetch();
      setIsSearching(false);
      toast({
        title: "Weather Updated",
        description: `Weather forecast for ${location} has been updated.`,
      });
    }, 1000);
  };
  
  // Sample data for visualizations
  const rainfallData = [
    { name: 'Jan', rainfall: 20, avg: 25 },
    { name: 'Feb', rainfall: 30, avg: 35 },
    { name: 'Mar', rainfall: 45, avg: 40 },
    { name: 'Apr', rainfall: 80, avg: 75 },
    { name: 'May', rainfall: 150, avg: 140 },
    { name: 'Jun', rainfall: 200, avg: 190 },
    { name: 'Jul', rainfall: 250, avg: 230 },
    { name: 'Aug', rainfall: 220, avg: 220 },
    { name: 'Sep', rainfall: 180, avg: 170 },
    { name: 'Oct', rainfall: 90, avg: 85 },
    { name: 'Nov', rainfall: 40, avg: 45 },
    { name: 'Dec', rainfall: 20, avg: 25 },
  ];
  
  const temperatureData = [
    { name: '6 AM', temperature: 21 },
    { name: '9 AM', temperature: 24 },
    { name: '12 PM', temperature: 28 },
    { name: '3 PM', temperature: 30 },
    { name: '6 PM', temperature: 27 },
    { name: '9 PM', temperature: 24 },
    { name: '12 AM', temperature: 22 },
    { name: '3 AM', temperature: 20 },
  ];
  
  const windData = [
    { time: '6 AM', speed: 8 },
    { time: '9 AM', speed: 10 },
    { time: '12 PM', speed: 12 },
    { time: '3 PM', speed: 15 },
    { time: '6 PM', speed: 13 },
    { time: '9 PM', speed: 10 },
    { time: '12 AM', speed: 7 },
    { time: '3 AM', speed: 5 },
  ];

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <FadeIn>
          <div className="mb-6">
            <h1 className="font-heading font-bold text-3xl text-neutral-800">
              Weather & Rainfall Prediction
            </h1>
            <p className="text-neutral-600 mt-1">
              Get accurate weather forecasts and rainfall predictions for better farming decisions
            </p>
          </div>
        </FadeIn>

        <SlideUp>
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 mb-8">
            <div className="flex-grow">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search location..."
                  className="pl-10"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSearch();
                  }}
                />
                <i className="ri-map-pin-line absolute left-3 top-2.5 text-neutral-500"></i>
              </div>
            </div>
            <Button 
              className="bg-primary hover:bg-primary-dark"
              onClick={handleSearch}
              disabled={isSearching}
            >
              {isSearching ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Searching...
                </>
              ) : (
                <>
                  <i className="ri-search-line mr-1"></i>
                  Search
                </>
              )}
            </Button>
          </div>
        </SlideUp>

        {/* Current Weather */}
        <div className="mb-8">
          <Card className="overflow-hidden">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-10"></div>
              <div className="relative p-6 md:p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    {isLoading ? (
                      <div className="space-y-4">
                        <Skeleton className="h-8 w-48" />
                        <Skeleton className="h-6 w-32" />
                        <Skeleton className="h-12 w-24" />
                        <Skeleton className="h-6 w-40" />
                      </div>
                    ) : weatherForecasts && weatherForecasts.length > 0 ? (
                      <div>
                        <motion.h2
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5 }}
                          className="font-heading font-bold text-2xl text-neutral-800 mb-1"
                        >
                          {location}
                        </motion.h2>
                        <motion.p
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.1 }}
                          className="text-neutral-600"
                        >
                          {new Date(weatherForecasts[0].date).toLocaleDateString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </motion.p>
                        
                        <div className="flex items-end mt-6">
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5, delay: 0.2 }}
                            className="text-6xl font-bold text-neutral-800"
                          >
                            {Math.round(weatherForecasts[0].temperature)}°
                          </motion.div>
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 0.5, delay: 0.3 }}
                            className="ml-4 mb-2"
                          >
                            <div className="flex items-center mb-1">
                              <i className={`${WEATHER_ICONS[weatherForecasts[0].weatherCondition] || "ri-sun-line"} text-2xl text-secondary mr-2`}></i>
                              <span className="font-medium text-neutral-700">
                                {weatherForecasts[0].weatherCondition}
                              </span>
                            </div>
                            <div className="text-neutral-600">
                              Humidity: {weatherForecasts[0].humidity}%
                            </div>
                          </motion.div>
                        </div>
                      </div>
                    ) : (
                      <div className="py-8">
                        <i className="ri-cloudy-line text-4xl text-neutral-400 mb-2"></i>
                        <p className="text-neutral-600">
                          No weather data available for this location
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <div className="flex flex-wrap justify-between mb-4">
                      <h3 className="font-medium text-neutral-700">Today's Forecast</h3>
                      <span className="text-sm text-neutral-500">Hourly</span>
                    </div>
                    <div className="overflow-x-auto pb-2">
                      <div className="flex space-x-4 min-w-max">
                        {[...Array(8)].map((_, i) => {
                          const hour = (6 + i * 3) % 24;
                          const period = hour >= 12 ? 'PM' : 'AM';
                          const displayHour = hour % 12 === 0 ? 12 : hour % 12;
                          
                          return (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ duration: 0.3, delay: 0.1 * i }}
                              className="flex flex-col items-center bg-white bg-opacity-50 rounded-lg p-3"
                            >
                              <div className="text-sm text-neutral-700">
                                {displayHour} {period}
                              </div>
                              <div className="text-secondary text-xl my-2">
                                <i className={`${i % 4 === 0 ? "ri-sun-line" : i % 4 === 1 ? "ri-sun-cloudy-line" : i % 4 === 2 ? "ri-cloudy-line" : "ri-drizzle-line"}`}></i>
                              </div>
                              <div className="font-medium">
                                {Math.round(20 + i * 1.5)}°
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-5 divide-y md:divide-y-0 md:divide-x">
              {weatherForecasts && weatherForecasts.slice(0, 5).map((forecast, index) => {
                const date = new Date(forecast.date);
                const dayName = DAYS_OF_WEEK[date.getDay()];
                const icon = WEATHER_ICONS[forecast.weatherCondition] || "ri-cloudy-line";
                
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: 0.1 * index }}
                    className="p-4 text-center"
                  >
                    <div className="text-neutral-600">{dayName}</div>
                    <div className="text-secondary text-2xl my-2">
                      <i className={icon}></i>
                    </div>
                    <div className="font-medium text-lg">{Math.round(forecast.temperature)}°</div>
                    <div className="text-xs text-neutral-500 mt-1">
                      Rainfall: {forecast.rainfall}mm
                    </div>
                  </motion.div>
                );
              })}
              
              {isLoading && (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="p-4 text-center">
                    <Skeleton className="h-4 w-12 mx-auto mb-2" />
                    <Skeleton className="h-8 w-8 mx-auto mb-2 rounded-full" />
                    <Skeleton className="h-6 w-10 mx-auto mb-1" />
                    <Skeleton className="h-3 w-20 mx-auto" />
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
        
        {/* Detailed Weather Tabs */}
        <Tabs defaultValue="rainfall" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="rainfall">Rainfall</TabsTrigger>
            <TabsTrigger value="temperature">Temperature</TabsTrigger>
            <TabsTrigger value="wind">Wind</TabsTrigger>
            <TabsTrigger value="humidity">Humidity</TabsTrigger>
          </TabsList>
          
          <TabsContent value="rainfall">
            <Card>
              <CardHeader>
                <CardTitle>Rainfall Prediction</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium text-neutral-700">
                      Monthly Rainfall (mm)
                    </h3>
                    <select className="bg-white border border-neutral-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
                      <option>Current Year</option>
                      <option>Last Year</option>
                      <option>5-Year Average</option>
                    </select>
                  </div>
                  
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={rainfallData}
                        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`${value} mm`, 'Rainfall']} />
                        <Bar dataKey="rainfall" name="Current Year" fill="#2D7738" />
                        <Bar dataKey="avg" name="Historical Average" fill="#8B5A2B" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Annual Rainfall</h3>
                    <div className="text-2xl font-bold text-primary">1,325 mm</div>
                    <p className="text-xs text-success mt-1 flex items-center">
                      <i className="ri-arrow-up-line mr-1"></i>
                      <span>5.2% above normal</span>
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Monsoon Status</h3>
                    <div className="text-2xl font-bold text-primary">Active</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Next 7 days: Heavy rainfall expected
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Crop Water Requirements</h3>
                    <div className="text-2xl font-bold text-primary">Fulfilled</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      No additional irrigation required this week
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="temperature">
            <Card>
              <CardHeader>
                <CardTitle>Temperature Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={temperatureData}
                        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[15, 35]} />
                        <Tooltip formatter={(value) => [`${value}°C`, 'Temperature']} />
                        <Line type="monotone" dataKey="temperature" stroke="#8B5A2B" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Today's High</h3>
                    <div className="text-2xl font-bold text-secondary">30°C</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Expected at 3:00 PM
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Today's Low</h3>
                    <div className="text-2xl font-bold text-secondary">20°C</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Expected at 5:00 AM
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Heat Index</h3>
                    <div className="text-2xl font-bold text-secondary">32°C</div>
                    <p className="text-xs text-warning mt-1">
                      Moderate heat alert for outdoor work
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="wind">
            <Card>
              <CardHeader>
                <CardTitle>Wind Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={windData}
                        margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                      >
                        <defs>
                          <linearGradient id="colorWind" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#E3B448" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="#E3B448" stopOpacity={0.1} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`${value} km/h`, 'Wind Speed']} />
                        <Area
                          type="monotone"
                          dataKey="speed"
                          stroke="#E3B448"
                          fillOpacity={1}
                          fill="url(#colorWind)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Wind Direction</h3>
                    <div className="flex items-center">
                      <div className="text-2xl font-bold text-accent mr-2">SW</div>
                      <i className="ri-compass-3-line text-2xl text-accent"></i>
                    </div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Southwest winds prevailing
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Max Wind Speed</h3>
                    <div className="text-2xl font-bold text-accent">15 km/h</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Expected at 3:00 PM
                    </p>
                  </div>
                  
                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Farming Advisory</h3>
                    <div className="text-base font-medium text-accent">Safe for Spraying</div>
                    <p className="text-xs text-neutral-500 mt-1">
                      Wind conditions are suitable for pesticide application
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="humidity">
            <Card>
              <CardHeader>
                <CardTitle>Humidity & Moisture</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-neutral-50 p-6 rounded-lg">
                    <h3 className="font-medium text-neutral-700 mb-4">Relative Humidity</h3>
                    <div className="flex items-center justify-center mb-4">
                      <div className="relative w-40 h-40">
                        <svg viewBox="0 0 100 100" className="w-full h-full">
                          <circle
                            cx="50"
                            cy="50"
                            r="45"
                            fill="none"
                            stroke="#e5e7eb"
                            strokeWidth="10"
                          />
                          <motion.circle
                            cx="50"
                            cy="50"
                            r="45"
                            fill="none"
                            stroke="#2D7738"
                            strokeWidth="10"
                            strokeDasharray="282.74"
                            strokeDashoffset="70.69"
                            initial={{ strokeDashoffset: 282.74 }}
                            animate={{ strokeDashoffset: 70.69 }}
                            transition={{ duration: 1.5 }}
                            strokeLinecap="round"
                            transform="rotate(-90 50 50)"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="text-3xl font-bold text-primary">75%</div>
                        </div>
                      </div>
                    </div>
                    <div className="text-center text-neutral-600">
                      High humidity may increase disease pressure in crops
                    </div>
                  </div>
                  
                  <div className="bg-neutral-50 p-6 rounded-lg">
                    <h3 className="font-medium text-neutral-700 mb-4">Soil Moisture</h3>
                    <div className="grid grid-cols-3 gap-4 text-center mb-4">
                      <div>
                        <div className="mb-2">
                          <div className="relative w-full pt-[100%]">
                            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                              <circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#e5e7eb"
                                strokeWidth="10"
                              />
                              <motion.circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#8B5A2B"
                                strokeWidth="10"
                                strokeDasharray="282.74"
                                strokeDashoffset="84.82"
                                initial={{ strokeDashoffset: 282.74 }}
                                animate={{ strokeDashoffset: 84.82 }}
                                transition={{ duration: 1.5 }}
                                strokeLinecap="round"
                                transform="rotate(-90 50 50)"
                              />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-xl font-bold text-secondary">70%</div>
                            </div>
                          </div>
                        </div>
                        <div className="text-sm text-neutral-700">Surface</div>
                      </div>
                      
                      <div>
                        <div className="mb-2">
                          <div className="relative w-full pt-[100%]">
                            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                              <circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#e5e7eb"
                                strokeWidth="10"
                              />
                              <motion.circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#8B5A2B"
                                strokeWidth="10"
                                strokeDasharray="282.74"
                                strokeDashoffset="113.1"
                                initial={{ strokeDashoffset: 282.74 }}
                                animate={{ strokeDashoffset: 113.1 }}
                                transition={{ duration: 1.5 }}
                                strokeLinecap="round"
                                transform="rotate(-90 50 50)"
                              />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-xl font-bold text-secondary">60%</div>
                            </div>
                          </div>
                        </div>
                        <div className="text-sm text-neutral-700">30 cm</div>
                      </div>
                      
                      <div>
                        <div className="mb-2">
                          <div className="relative w-full pt-[100%]">
                            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                              <circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#e5e7eb"
                                strokeWidth="10"
                              />
                              <motion.circle
                                cx="50"
                                cy="50"
                                r="45"
                                fill="none"
                                stroke="#8B5A2B"
                                strokeWidth="10"
                                strokeDasharray="282.74"
                                strokeDashoffset="141.37"
                                initial={{ strokeDashoffset: 282.74 }}
                                animate={{ strokeDashoffset: 141.37 }}
                                transition={{ duration: 1.5 }}
                                strokeLinecap="round"
                                transform="rotate(-90 50 50)"
                              />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-xl font-bold text-secondary">50%</div>
                            </div>
                          </div>
                        </div>
                        <div className="text-sm text-neutral-700">60 cm</div>
                      </div>
                    </div>
                    <div className="text-center text-neutral-600">
                      Soil moisture levels are adequate for most crops
                    </div>
                  </div>
                </div>
                
                <div className="bg-neutral-50 p-6 rounded-lg">
                  <h3 className="font-medium text-neutral-700 mb-4">Crop Specific Recommendations</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="bg-primary bg-opacity-10 p-2 rounded-full mr-3">
                        <i className="ri-plant-line text-xl text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-neutral-800 mb-1">Rice</h4>
                        <p className="text-neutral-600 text-sm">
                          Current humidity levels are favorable for rice cultivation. Maintain standing water in the field to prevent moisture stress.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-primary bg-opacity-10 p-2 rounded-full mr-3">
                        <i className="ri-seedling-line text-xl text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-neutral-800 mb-1">Wheat</h4>
                        <p className="text-neutral-600 text-sm">
                          High humidity might increase the risk of fungal diseases. Consider preventive fungicide application if symptoms appear.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-primary bg-opacity-10 p-2 rounded-full mr-3">
                        <i className="ri-leaf-line text-xl text-primary"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-neutral-800 mb-1">Vegetables</h4>
                        <p className="text-neutral-600 text-sm">
                          Ensure good air circulation in vegetable crops to reduce disease pressure under current humidity conditions.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageTransition>
  );
};

export default Weather;
