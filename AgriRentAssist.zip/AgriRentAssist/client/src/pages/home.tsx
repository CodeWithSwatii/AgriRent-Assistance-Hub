import { motion } from "framer-motion";
import { PageTransition } from "@/components/ui/animations";
import HeroSection from "@/components/home/hero-section";
import SmartFarmingSection from "@/components/smart-farming/smart-farming-section";
import MarketplaceSection from "@/components/marketplace/marketplace-section";
import MarketPricesSection from "@/components/market-prices/market-prices-section";
import GovernmentResourcesSection from "@/components/government/government-resources-section";
import WelcomeDialog from "@/components/home/welcome-dialog";

const Home = () => {

  return (
    <PageTransition>
      {/* Welcome Dialog that auto-dismisses */}
      <WelcomeDialog />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <HeroSection />
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <SmartFarmingSection />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <MarketplaceSection />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <MarketPricesSection />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <GovernmentResourcesSection />
        </motion.div>
      </div>
    </PageTransition>
  );
};

export default Home;
