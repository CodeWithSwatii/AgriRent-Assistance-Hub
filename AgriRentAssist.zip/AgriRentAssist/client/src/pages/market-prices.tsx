import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { PageTransition, FadeIn, SlideUp, StaggerChildren, StaggerItem } from "@/components/ui/animations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { TableSkeleton } from "@/components/ui/loading-skeleton";
import { Skeleton } from "@/components/ui/skeleton";
import { MARKETS } from "@/lib/constants";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line } from 'recharts';
import { useToast } from "@/hooks/use-toast";
import type { MarketPrice } from "@shared/schema";

const MarketPrices = () => {
  const { toast } = useToast();
  const [selectedMarket, setSelectedMarket] = useState("Maharashtra");
  const [searchTerm, setSearchTerm] = useState("");
  const [isFiltering, setIsFiltering] = useState(false);
  
  // Fetch market prices
  const {
    isLoading,
    data: marketPrices,
    refetch
  } = useQuery<MarketPrice[]>({
    queryKey: ["/api/market-prices"],
  });
  
  const handleSearch = () => {
    setIsFiltering(true);
    // In a real implementation, this would update the query parameter and refetch
    setTimeout(() => {
      refetch();
      setIsFiltering(false);
      toast({
        title: "Prices Updated",
        description: `Market prices for ${searchTerm ? searchTerm : 'all crops'} in ${selectedMarket} have been updated.`,
      });
    }, 1000);
  };
  
  // Filter market prices based on search term
  const filteredPrices = marketPrices?.filter(price => {
    if (!searchTerm) return true;
    return price.crop.toLowerCase().includes(searchTerm.toLowerCase()) ||
           price.market.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (price.variety && price.variety.toLowerCase().includes(searchTerm.toLowerCase()));
  });
  
  // Sample data for price trend visualization
  const priceTrendData = [
    { month: 'Jan', wheat: 2000, rice: 3200, cotton: 5800 },
    { month: 'Feb', wheat: 2100, rice: 3300, cotton: 5900 },
    { month: 'Mar', wheat: 2050, rice: 3250, cotton: 6000 },
    { month: 'Apr', wheat: 2150, rice: 3400, cotton: 6100 },
    { month: 'May', wheat: 2200, rice: 3450, cotton: 6050 },
    { month: 'Jun', wheat: 2250, rice: 3500, cotton: 5950 },
    { month: 'Jul', wheat: 2300, rice: 3550, cotton: 6000 },
    { month: 'Aug', wheat: 2250, rice: 3500, cotton: 6100 },
    { month: 'Sep', wheat: 2200, rice: 3450, cotton: 6200 },
    { month: 'Oct', wheat: 2250, rice: 3400, cotton: 6150 },
    { month: 'Nov', wheat: 2200, rice: 3350, cotton: 6050 },
    { month: 'Dec', wheat: 2225, rice: 3450, cotton: 6120 },
  ];
  
  // Sample data for market comparison
  const marketComparisonData = [
    { market: 'Pune APMC', price: 2225 },
    { market: 'Nagpur APMC', price: 2180 },
    { market: 'Mumbai APMC', price: 2300 },
    { market: 'Kolhapur APMC', price: 2150 },
    { market: 'Nashik APMC', price: 2200 },
  ];

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <FadeIn>
          <div className="mb-6">
            <h1 className="font-heading font-bold text-3xl text-neutral-800">
              Live Market Prices
            </h1>
            <p className="text-neutral-600 mt-1">
              Real-time crop prices from major agricultural markets to help you make informed decisions
            </p>
          </div>
        </FadeIn>

        <SlideUp>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="md:col-span-2">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search by crop, market or variety..."
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSearch();
                  }}
                />
                <i className="ri-search-line absolute left-3 top-2.5 text-neutral-500"></i>
              </div>
            </div>
            <div>
              <Select value={selectedMarket} onValueChange={setSelectedMarket}>
                {MARKETS.map((market) => (
                  <option key={market} value={market}>
                    {market}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Button 
                className="w-full bg-primary hover:bg-primary-dark"
                onClick={handleSearch}
                disabled={isFiltering}
              >
                {isFiltering ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Updating...
                  </>
                ) : (
                  <>
                    <i className="ri-refresh-line mr-1"></i>
                    Update Prices
                  </>
                )}
              </Button>
            </div>
          </div>
        </SlideUp>
        
        {/* Price Overview */}
        <StaggerChildren className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StaggerItem>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-neutral-500">
                  Avg Price Today
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <div className="text-2xl font-bold">
                    ₹{marketPrices && marketPrices.length > 0 
                      ? Math.round(marketPrices.reduce((sum, price) => sum + price.price, 0) / marketPrices.length)
                      : 0}
                    <span className="text-sm font-normal text-neutral-500">/quintal</span>
                  </div>
                )}
                <p className="text-xs text-success flex items-center mt-1">
                  <i className="ri-arrow-up-line mr-1"></i>
                  <span>3.2% from yesterday</span>
                </p>
              </CardContent>
            </Card>
          </StaggerItem>
          
          <StaggerItem>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-neutral-500">
                  Highest Priced Crop
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-8 w-36" />
                ) : (
                  <div className="text-2xl font-bold">
                    {marketPrices && marketPrices.length > 0 
                      ? marketPrices.reduce((prev, current) => (prev.price > current.price) ? prev : current).crop
                      : "N/A"}
                  </div>
                )}
                <p className="text-xs text-neutral-600 flex items-center mt-1">
                  <span>
                    {marketPrices && marketPrices.length > 0 
                      ? `₹${marketPrices.reduce((prev, current) => (prev.price > current.price) ? prev : current).price}/quintal`
                      : ""}
                  </span>
                </p>
              </CardContent>
            </Card>
          </StaggerItem>
          
          <StaggerItem>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-neutral-500">
                  Price Volatility
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Moderate</div>
                <p className="text-xs text-warning flex items-center mt-1">
                  <i className="ri-alert-line mr-1"></i>
                  <span>Watch cotton prices closely</span>
                </p>
              </CardContent>
            </Card>
          </StaggerItem>
        </StaggerChildren>

        {/* Market Prices Table */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Current Market Prices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-neutral-100">
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Crop</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Market</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Variety</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">
                      Price (₹/Quintal)
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Change</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Updated</th>
                    <th className="px-6 py-4 text-left text-sm font-medium text-neutral-700">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {isLoading ? (
                    <TableSkeleton rows={8} />
                  ) : filteredPrices && filteredPrices.length > 0 ? (
                    filteredPrices.map((price) => {
                      const priceChange = price.price - (price.previousPrice || price.price);
                      const changePercent = price.previousPrice
                        ? ((priceChange / price.previousPrice) * 100).toFixed(2)
                        : "0.00";
                      const isPositive = priceChange >= 0;

                      // Calculate the time difference
                      const now = new Date();
                      const updated = price.updatedAt ? new Date(price.updatedAt) : new Date();
                      const diffMs = now.getTime() - updated.getTime();
                      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                      
                      let updatedText = "";
                      if (diffHrs > 0) {
                        updatedText = `${diffHrs} ${diffHrs === 1 ? "hour" : "hours"} ago`;
                      } else {
                        updatedText = `${diffMins} ${diffMins === 1 ? "minute" : "minutes"} ago`;
                      }

                      return (
                        <motion.tr
                          key={price.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.3 }}
                          className="hover:bg-neutral-50 transition-all"
                        >
                          <td className="px-6 py-4 text-sm font-medium text-neutral-700">{price.crop}</td>
                          <td className="px-6 py-4 text-sm text-neutral-600">{price.market}</td>
                          <td className="px-6 py-4 text-sm text-neutral-600">{price.variety || "Standard"}</td>
                          <td className="px-6 py-4 text-sm font-medium text-neutral-800">
                            ₹{price.price.toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <div
                              className={`inline-flex items-center ${
                                isPositive ? "text-success" : "text-error"
                              }`}
                            >
                              <i
                                className={`${
                                  isPositive ? "ri-arrow-up-line" : "ri-arrow-down-line"
                                } mr-1`}
                              ></i>
                              <span className="text-sm font-medium">
                                ₹{Math.abs(priceChange)} ({Math.abs(parseFloat(changePercent))}%)
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-neutral-500">{updatedText}</td>
                          <td className="px-6 py-4 text-sm">
                            <Button variant="ghost" size="sm" className="h-8 px-2 text-primary">
                              <i className="ri-line-chart-line mr-1"></i> View History
                            </Button>
                          </td>
                        </motion.tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={7} className="px-6 py-10 text-center">
                        <div className="flex flex-col items-center">
                          <i className="ri-emotion-sad-line text-3xl text-neutral-400 mb-2"></i>
                          <p className="text-neutral-600 font-medium mb-1">No market prices found</p>
                          <p className="text-neutral-500 text-sm">
                            {searchTerm ? `No results for "${searchTerm}". Try a different search term.` : 'Try selecting a different market or check back later.'}
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
        
        {/* Price Trends Graph */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Annual Price Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-medium text-neutral-700">Major Crops Price Comparison</h3>
                <select className="bg-white border border-neutral-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
                  <option>Last 12 Months</option>
                  <option>Last 6 Months</option>
                  <option>Last 3 Months</option>
                </select>
              </div>
              
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={priceTrendData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[0, 'dataMax + 500']} />
                    <Tooltip formatter={(value) => [`₹${value}`, '']} />
                    <Area type="monotone" dataKey="wheat" name="Wheat" stroke="#2D7738" fill="#2D7738" fillOpacity={0.1} />
                    <Area type="monotone" dataKey="rice" name="Rice" stroke="#8B5A2B" fill="#8B5A2B" fillOpacity={0.1} />
                    <Area type="monotone" dataKey="cotton" name="Cotton" stroke="#E3B448" fill="#E3B448" fillOpacity={0.1} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Market Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-medium text-neutral-700">Wheat Prices Across Markets</h3>
                <select className="bg-white border border-neutral-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
                  <option>Wheat</option>
                  <option>Rice</option>
                  <option>Cotton</option>
                  <option>Sugarcane</option>
                  <option>Soybean</option>
                </select>
              </div>
              
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={marketComparisonData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" domain={[0, 'dataMax + 200']} />
                    <YAxis dataKey="market" type="category" width={100} />
                    <Tooltip formatter={(value) => [`₹${value}`, 'Price']} />
                    <Bar dataKey="price" fill="#2D7738" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Price Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Market Insights & Advisory</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-neutral-50 p-5 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="bg-primary bg-opacity-10 p-2 rounded-lg mr-3">
                    <i className="ri-line-chart-line text-xl text-primary"></i>
                  </div>
                  <h3 className="font-heading font-semibold text-neutral-800">Price Forecast</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Wheat prices are expected to remain stable over the next month, with potential increases during the harvest season.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="ri-check-line text-success mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">Hold wheat stocks for potential price rise in May</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-check-line text-success mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">Consider selling cotton at current prices</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-neutral-50 p-5 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="bg-secondary bg-opacity-10 p-2 rounded-lg mr-3">
                    <i className="ri-government-line text-xl text-secondary"></i>
                  </div>
                  <h3 className="font-heading font-semibold text-neutral-800">Policy Updates</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Recent government policies affecting agricultural commodity pricing and market regulations.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="ri-information-line text-secondary mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">MSP for wheat increased by 4.5% for the upcoming season</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-information-line text-secondary mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">New export regulations for rice effective from next month</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-neutral-50 p-5 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="bg-accent bg-opacity-10 p-2 rounded-lg mr-3">
                    <i className="ri-exchange-funds-line text-xl text-accent"></i>
                  </div>
                  <h3 className="font-heading font-semibold text-neutral-800">Market Opportunities</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Potential market arbitrage and selling opportunities across different regions.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="ri-arrow-right-circle-line text-accent mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">10% price difference for rice between Pune and Mumbai markets</span>
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-circle-line text-accent mt-1 mr-2"></i>
                    <span className="text-sm text-neutral-700">Consider transportation to Nagpur for better soybean prices</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
};

export default MarketPrices;
