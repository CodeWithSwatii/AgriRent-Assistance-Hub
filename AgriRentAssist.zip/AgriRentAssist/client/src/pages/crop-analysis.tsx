import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { PageTransition, FadeIn, SlideUp } from "@/components/ui/animations";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useDropzone } from "react-dropzone";
import { Skeleton } from "@/components/ui/loading-skeleton";
import SoilAnalysisCard from "@/components/smart-farming/soil-analysis-card";
import CropRecommendationCard from "@/components/smart-farming/crop-recommendation-card";
import FertilizerRecommendationCard from "@/components/smart-farming/fertilizer-recommendation-card";
import RecommendationNotification from "@/components/smart-farming/recommendation-notification";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import type { SoilAnalysis, CropRecommendation } from "@shared/schema";

const CropAnalysis = () => {
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("soil-analysis");
  const [isUploading, setIsUploading] = useState(false);
  const [cropType, setCropType] = useState("");
  const [soilType, setSoilType] = useState("");
  const [showRecommendation, setShowRecommendation] = useState(false);
  
  // Check URL parameters for tab selection
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab');
    if (tabParam) {
      setActiveTab(tabParam);
    }
  }, []);
  
  // Fetch soil analyses
  const { data: soilAnalyses, isLoading: isLoadingSoil } = useQuery<SoilAnalysis[]>({
    queryKey: ["/api/soil-analyses?userId=1"],
  });
  
  // Fetch crop recommendations
  const { data: cropRecommendations, isLoading: isLoadingRecommendations } = useQuery<CropRecommendation[]>({
    queryKey: ["/api/crop-recommendations?userId=1"],
  });
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    },
    maxFiles: 1,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        handleFileUpload(acceptedFiles[0]);
      }
    }
  });
  
  const handleFileUpload = (file: File) => {
    setIsUploading(true);
    
    // Simulate file upload processing
    setTimeout(() => {
      setIsUploading(false);
      toast({
        title: "File Uploaded Successfully",
        description: "Your soil report has been processed and analyzed.",
      });
    }, 2000);
  };
  
  const handleAnalyze = () => {
    if (!cropType || !soilType) {
      toast({
        title: "Missing Information",
        description: "Please select both crop type and soil type.",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Analysis Started",
      description: "Analyzing crop suitability for your selection...",
    });
    
    // Simulate analysis with a delay, then show the recommendation notification
    setTimeout(() => {
      // Show the recommendation notification
      setShowRecommendation(true);
      
      // Automatically switch to recommendations tab after a short delay
      setTimeout(() => {
        setActiveTab("crop-recommendation");
      }, 1000);
    }, 3000);
  };
  
  // Sample data for visualizations
  const nutrientLevels = [
    { subject: 'Nitrogen', A: soilAnalyses?.[0]?.nitrogen || 35, fullMark: 100 },
    { subject: 'Phosphorus', A: soilAnalyses?.[0]?.phosphorus || 72, fullMark: 100 },
    { subject: 'Potassium', A: soilAnalyses?.[0]?.potassium || 68, fullMark: 100 },
    { subject: 'pH Level', A: soilAnalyses?.[0]?.pHLevel ? soilAnalyses[0].pHLevel * 10 : 68, fullMark: 100 },
    { subject: 'Organic Matter', A: soilAnalyses?.[0]?.organicMatter ? soilAnalyses[0].organicMatter * 20 : 50, fullMark: 100 },
  ];
  
  const rainfallData = [
    { name: 'Jan', rainfall: 20 },
    { name: 'Feb', rainfall: 30 },
    { name: 'Mar', rainfall: 45 },
    { name: 'Apr', rainfall: 80 },
    { name: 'May', rainfall: 150 },
    { name: 'Jun', rainfall: 200 },
    { name: 'Jul', rainfall: 250 },
    { name: 'Aug', rainfall: 220 },
    { name: 'Sep', rainfall: 180 },
    { name: 'Oct', rainfall: 90 },
    { name: 'Nov', rainfall: 40 },
    { name: 'Dec', rainfall: 20 },
  ];

  return (
    <PageTransition>
      {/* Recommendation notification that appears after analysis */}
      <RecommendationNotification 
        show={showRecommendation} 
        onClose={() => setShowRecommendation(false)} 
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <FadeIn>
          <div className="mb-6">
            <h1 className="font-heading font-bold text-3xl text-neutral-800">Crop Analysis & Optimization</h1>
            <p className="text-neutral-600 mt-1">
              Get AI-powered insights to maximize your crop yield and optimize farming practices
            </p>
          </div>
        </FadeIn>

        <SlideUp>
          <Tabs defaultValue="soil-analysis" className="mb-8" onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="soil-analysis">Soil Analysis</TabsTrigger>
              <TabsTrigger value="crop-recommendation">Crop Recommendation</TabsTrigger>
              <TabsTrigger value="fertilizer-guide">Fertilizer Guide</TabsTrigger>
              <TabsTrigger value="rainfall-prediction">Rainfall Prediction</TabsTrigger>
            </TabsList>

            <TabsContent value="soil-analysis">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Soil Report Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-6">
                        <div {...getRootProps()} className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${isDragActive ? 'border-primary bg-primary bg-opacity-5' : 'border-neutral-300'} ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}>
                          <input {...getInputProps()} />
                          <i className={`${isUploading ? 'ri-loader-4-line animate-spin' : 'ri-upload-cloud-2-line'} text-4xl text-neutral-500 mb-2`}></i>
                          <h3 className="font-medium text-neutral-700 mb-1">
                            {isUploading ? 'Uploading...' : isDragActive ? 'Drop the file here' : 'Upload Soil Test Report'}
                          </h3>
                          <p className="text-sm text-neutral-500">
                            Drag and drop your soil test report, or click to select file
                          </p>
                          <p className="text-xs text-neutral-400 mt-2">
                            Supports: PDF, JPG, PNG (Max size: 10MB)
                          </p>
                        </div>
                      </div>

                      {isLoadingSoil ? (
                        <div className="space-y-4">
                          <Skeleton className="h-60 w-full" />
                        </div>
                      ) : soilAnalyses && soilAnalyses.length > 0 ? (
                        <div>
                          <h3 className="font-medium text-neutral-700 mb-4">Soil Nutrient Levels</h3>
                          <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                              <RadarChart outerRadius={120} data={nutrientLevels}>
                                <PolarGrid />
                                <PolarAngleAxis dataKey="subject" />
                                <PolarRadiusAxis angle={30} domain={[0, 100]} />
                                <Radar name="Nutrient Levels" dataKey="A" stroke="#2D7738" fill="#2D7738" fillOpacity={0.5} />
                                <Tooltip />
                              </RadarChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <i className="ri-flask-line text-3xl text-neutral-400 mb-2"></i>
                          <p className="text-neutral-600">No soil analysis data found</p>
                          <p className="text-sm text-neutral-500 mt-1 mb-4">
                            Upload a soil test report to get detailed insights
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <SoilAnalysisCard loading={isLoadingSoil} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="crop-recommendation">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Crop Recommendation Engine</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                          <Label htmlFor="crop-type">Preferred Crop Type</Label>
                          <select
                            id="crop-type"
                            value={cropType}
                            onChange={(e) => setCropType(e.target.value)}
                            className="w-full p-2 mt-1 bg-neutral-100 border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                          >
                            <option value="">Select crop type</option>
                            <option value="wheat">Wheat</option>
                            <option value="rice">Rice</option>
                            <option value="maize">Maize</option>
                            <option value="cotton">Cotton</option>
                            <option value="sugarcane">Sugarcane</option>
                            <option value="pulses">Pulses</option>
                          </select>
                        </div>
                        <div>
                          <Label htmlFor="soil-type">Soil Type</Label>
                          <select
                            id="soil-type"
                            value={soilType}
                            onChange={(e) => setSoilType(e.target.value)}
                            className="w-full p-2 mt-1 bg-neutral-100 border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                          >
                            <option value="">Select soil type</option>
                            <option value="clay">Clay Soil</option>
                            <option value="sandy">Sandy Soil</option>
                            <option value="loamy">Loamy Soil</option>
                            <option value="silty">Silty Soil</option>
                            <option value="peaty">Peaty Soil</option>
                            <option value="chalky">Chalky Soil</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex justify-center mb-6">
                        <Button 
                          className="bg-primary hover:bg-primary-dark"
                          onClick={handleAnalyze}
                        >
                          <i className="ri-plant-line mr-1"></i> 
                          Analyze Crop Suitability
                        </Button>
                      </div>

                      {isLoadingRecommendations ? (
                        <div className="space-y-4">
                          <Skeleton className="h-40 w-full" />
                        </div>
                      ) : cropRecommendations && cropRecommendations.length > 0 ? (
                        <div>
                          <h3 className="font-medium text-neutral-700 mb-4">AI-Generated Crop Insights</h3>
                          <div className="bg-neutral-50 p-4 rounded-lg mb-4">
                            <h4 className="font-medium text-neutral-800 mb-2">Recommended Crops</h4>
                            <div className="flex flex-wrap gap-2">
                              {((cropRecommendations[0].recommendations as any).crops as string[]).map((crop, index) => (
                                <motion.span
                                  key={index}
                                  initial={{ opacity: 0, scale: 0.8 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  transition={{ duration: 0.3, delay: index * 0.1 }}
                                  className={`${cropType.toLowerCase() === crop.toLowerCase() ? 'bg-primary text-white' : 'bg-primary bg-opacity-10 text-primary'} px-3 py-1 rounded-full text-sm cursor-pointer`}
                                  onClick={() => setCropType(crop.toLowerCase())}
                                >
                                  {crop}
                                </motion.span>
                              ))}
                            </div>
                          </div>
                          
                          {cropType && (cropRecommendations[0].recommendations as any).cropDetails && (cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()] ? (
                            <div className="space-y-5">
                              <h4 className="font-medium text-neutral-800">Specific Information for {cropType}</h4>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="bg-neutral-50 p-4 rounded-lg">
                                  <h4 className="font-medium text-neutral-800 mb-2">Optimal Season</h4>
                                  <p className="text-neutral-700">
                                    {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].season}
                                  </p>
                                </div>
                                <div className="bg-neutral-50 p-4 rounded-lg">
                                  <h4 className="font-medium text-neutral-800 mb-2">Irrigation Needs</h4>
                                  <p className="text-neutral-700">
                                    {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].irrigationNeeds}
                                  </p>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="bg-neutral-50 p-4 rounded-lg">
                                  <h4 className="font-medium text-neutral-800 mb-2">Ideal Soil Type</h4>
                                  <p className="text-neutral-700">
                                    {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].soilType}
                                  </p>
                                </div>
                                <div className="bg-neutral-50 p-4 rounded-lg">
                                  <h4 className="font-medium text-neutral-800 mb-2">Fertilizer Recommendations</h4>
                                  <ul className="text-neutral-700 space-y-1 list-disc pl-4">
                                    <li>Nitrogen: {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].fertilizers.nitrogen}</li>
                                    <li>Phosphorus: {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].fertilizers.phosphorus}</li>
                                    <li>Potassium: {(cropRecommendations[0].recommendations as any).cropDetails[cropType.toLowerCase()].fertilizers.potassium}</li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="bg-neutral-50 p-4 rounded-lg">
                                <h4 className="font-medium text-neutral-800 mb-2">Recommendation</h4>
                                <p className="text-neutral-700">
                                  Please select a specific crop type for detailed information or click on one of the recommended crops above.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <i className="ri-seedling-line text-3xl text-neutral-400 mb-2"></i>
                          <p className="text-neutral-600">No crop recommendations found</p>
                          <p className="text-sm text-neutral-500 mt-1">
                            Select your preferences and analyze to get AI-powered recommendations
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <CropRecommendationCard loading={isLoadingRecommendations} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="fertilizer-guide">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Fertilizer Recommendation</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {soilAnalyses && soilAnalyses.length > 0 ? (
                        <div>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                            <div className="bg-neutral-50 p-4 rounded-lg">
                              <h3 className="text-sm font-medium text-neutral-700 mb-2">
                                Nitrogen (N) Status
                              </h3>
                              <div className="flex items-center justify-between">
                                <div className="text-lg font-bold">
                                  {soilAnalyses[0].nitrogen}
                                  <span className="text-xs font-normal ml-1">mg/kg</span>
                                </div>
                                <div className={`px-2 py-1 rounded text-xs font-medium ${soilAnalyses[0].nitrogen < 50 ? 'bg-warning bg-opacity-20 text-warning' : 'bg-success bg-opacity-20 text-success'}`}>
                                  {soilAnalyses[0].nitrogen < 50 ? 'Low' : 'Good'}
                                </div>
                              </div>
                              <div className="mt-2 h-2 bg-neutral-200 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-primary"
                                  initial={{ width: 0 }}
                                  animate={{ width: `${Math.min(soilAnalyses[0].nitrogen, 100)}%` }}
                                  transition={{ duration: 1 }}
                                ></motion.div>
                              </div>
                            </div>
                            
                            <div className="bg-neutral-50 p-4 rounded-lg">
                              <h3 className="text-sm font-medium text-neutral-700 mb-2">
                                Phosphorus (P) Status
                              </h3>
                              <div className="flex items-center justify-between">
                                <div className="text-lg font-bold">
                                  {soilAnalyses[0].phosphorus}
                                  <span className="text-xs font-normal ml-1">mg/kg</span>
                                </div>
                                <div className="px-2 py-1 rounded text-xs font-medium bg-success bg-opacity-20 text-success">
                                  Good
                                </div>
                              </div>
                              <div className="mt-2 h-2 bg-neutral-200 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-primary"
                                  initial={{ width: 0 }}
                                  animate={{ width: `${Math.min(soilAnalyses[0].phosphorus, 100)}%` }}
                                  transition={{ duration: 1 }}
                                ></motion.div>
                              </div>
                            </div>
                            
                            <div className="bg-neutral-50 p-4 rounded-lg">
                              <h3 className="text-sm font-medium text-neutral-700 mb-2">
                                Potassium (K) Status
                              </h3>
                              <div className="flex items-center justify-between">
                                <div className="text-lg font-bold">
                                  {soilAnalyses[0].potassium}
                                  <span className="text-xs font-normal ml-1">mg/kg</span>
                                </div>
                                <div className="px-2 py-1 rounded text-xs font-medium bg-success bg-opacity-20 text-success">
                                  Good
                                </div>
                              </div>
                              <div className="mt-2 h-2 bg-neutral-200 rounded-full overflow-hidden">
                                <motion.div
                                  className="h-full bg-primary"
                                  initial={{ width: 0 }}
                                  animate={{ width: `${Math.min(soilAnalyses[0].potassium, 100)}%` }}
                                  transition={{ duration: 1 }}
                                ></motion.div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="bg-neutral-50 p-6 rounded-lg mb-6">
                            <h3 className="font-medium text-neutral-800 mb-4">Fertilizer Recommendation</h3>
                            <div className="flex items-start">
                              <div className="bg-accent bg-opacity-10 p-2 rounded-lg mr-4">
                                <i className="ri-flask-line text-2xl text-accent"></i>
                              </div>
                              <div>
                                <p className="text-neutral-700 mb-3">
                                  Based on your soil analysis, we recommend using:
                                </p>
                                <div className="bg-white p-4 rounded-lg border border-neutral-200">
                                  <p className="font-medium text-lg text-neutral-800 mb-2">
                                    NPK 14-7-7 Fertilizer
                                  </p>
                                  <p className="text-neutral-600 text-sm">
                                    Apply 200 kg/hectare before sowing and 100 kg/hectare during the growing season for best results.
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div>
                            <h3 className="font-medium text-neutral-700 mb-3">Additional Recommendations</h3>
                            <ul className="space-y-2">
                              <li className="flex items-start">
                                <i className="ri-check-line text-success mt-1 mr-2"></i>
                                <span className="text-neutral-700">
                                  Consider adding organic matter to improve soil structure and water retention
                                </span>
                              </li>
                              <li className="flex items-start">
                                <i className="ri-check-line text-success mt-1 mr-2"></i>
                                <span className="text-neutral-700">
                                  Maintain soil pH at current levels as it's within optimal range
                                </span>
                              </li>
                              <li className="flex items-start">
                                <i className="ri-check-line text-success mt-1 mr-2"></i>
                                <span className="text-neutral-700">
                                  Apply micronutrients like zinc and boron if growing cereals or pulses
                                </span>
                              </li>
                            </ul>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-16">
                          <i className="ri-flask-line text-4xl text-neutral-400 mb-2"></i>
                          <p className="text-neutral-600 font-medium mb-2">
                            No soil analysis data available
                          </p>
                          <p className="text-neutral-500 max-w-md mx-auto mb-4">
                            We need soil analysis data to provide personalized fertilizer recommendations. Please upload a soil test report.
                          </p>
                          <Button className="bg-primary hover:bg-primary-dark">
                            Go to Soil Analysis
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <FertilizerRecommendationCard loading={isLoadingSoil} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="rainfall-prediction">
              <Card>
                <CardHeader>
                  <CardTitle>Annual Rainfall Prediction</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium text-neutral-700">
                        Rainfall Pattern (Maharashtra)
                      </h3>
                      <select className="bg-white border border-neutral-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
                        <option>Last 12 Months</option>
                        <option>Historical Average</option>
                        <option>5-Year Trend</option>
                      </select>
                    </div>
                    
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={rainfallData}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="colorRainfall" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#8B5A2B" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="#8B5A2B" stopOpacity={0.1} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis label={{ value: 'Rainfall (mm)', angle: -90, position: 'insideLeft' }} />
                          <Tooltip formatter={(value) => [`${value} mm`, 'Rainfall']} />
                          <Area
                            type="monotone"
                            dataKey="rainfall"
                            stroke="#8B5A2B"
                            fillOpacity={1}
                            fill="url(#colorRainfall)"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <h3 className="text-sm font-medium text-neutral-700 mb-2">Annual Rainfall</h3>
                      <div className="text-2xl font-bold text-secondary">1,210 mm</div>
                      <p className="text-xs text-neutral-500 mt-1">
                        5% above historical average
                      </p>
                    </div>
                    
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <h3 className="text-sm font-medium text-neutral-700 mb-2">Peak Rainfall Month</h3>
                      <div className="text-2xl font-bold text-secondary">July</div>
                      <p className="text-xs text-neutral-500 mt-1">
                        250 mm average precipitation
                      </p>
                    </div>
                    
                    <div className="bg-neutral-50 p-4 rounded-lg">
                      <h3 className="text-sm font-medium text-neutral-700 mb-2">Monsoon Period</h3>
                      <div className="text-2xl font-bold text-secondary">Jun - Sep</div>
                      <p className="text-xs text-neutral-500 mt-1">
                        78% of annual rainfall
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </SlideUp>
      </div>
    </PageTransition>
  );
};

export default CropAnalysis;
