import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { PageTransition, FadeIn, SlideUp } from "@/components/ui/animations";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import MarketplaceSection from "@/components/marketplace/marketplace-section";
import type { LandListing, EquipmentListing } from "@shared/schema";

const Marketplace = () => {
  const { toast } = useToast();
  const [showAddListingDialog, setShowAddListingDialog] = useState(false);
  const [listingType, setListingType] = useState<"land" | "equipment">("land");

  // Fetch land listings count
  const { data: landListings } = useQuery<LandListing[]>({
    queryKey: ["/api/land-listings"],
  });

  // Fetch equipment listings count
  const { data: equipmentListings } = useQuery<EquipmentListing[]>({
    queryKey: ["/api/equipment-listings"],
  });

  const landCount = landListings?.length || 0;
  const equipmentCount = equipmentListings?.length || 0;
  const totalListings = landCount + equipmentCount;

  const handleAddListing = (type: "land" | "equipment") => {
    setListingType(type);
    setShowAddListingDialog(true);
  };

  const handleCreateListing = () => {
    toast({
      title: "Listing Creation Started",
      description: `You're creating a new ${listingType} listing.`,
    });
    setShowAddListingDialog(false);
    // In a real implementation, this would navigate to a listing creation form
  };

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <FadeIn>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h1 className="font-heading font-bold text-3xl text-neutral-800">
                Agricultural Marketplace
              </h1>
              <p className="text-neutral-600 mt-1">
                Find or list agricultural land and equipment for rent, lease, or sale
              </p>
            </div>
            <div className="mt-4 md:mt-0 space-x-2">
              <Button
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white"
                onClick={() => handleAddListing("land")}
              >
                <i className="ri-landscape-line mr-1"></i> Add Land
              </Button>
              <Button 
                className="bg-primary hover:bg-primary-dark"
                onClick={() => handleAddListing("equipment")}
              >
                <i className="ri-tools-line mr-1"></i> Add Equipment
              </Button>
            </div>
          </div>
        </FadeIn>

        <SlideUp>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-semibold text-lg">Total Listings</h2>
                <div className="bg-primary bg-opacity-10 rounded-full w-10 h-10 flex items-center justify-center">
                  <i className="ri-store-2-line text-xl text-primary"></i>
                </div>
              </div>
              <div className="text-3xl font-bold text-neutral-800">
                {totalListings}
              </div>
              <p className="text-sm text-neutral-500 mt-1">
                Updated just now
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-semibold text-lg">Land Listings</h2>
                <div className="bg-secondary bg-opacity-10 rounded-full w-10 h-10 flex items-center justify-center">
                  <i className="ri-landscape-line text-xl text-secondary"></i>
                </div>
              </div>
              <div className="text-3xl font-bold text-neutral-800">{landCount}</div>
              <p className="text-sm text-neutral-500 mt-1">
                Includes rent, sale, and lease
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-semibold text-lg">Equipment Listings</h2>
                <div className="bg-accent bg-opacity-10 rounded-full w-10 h-10 flex items-center justify-center">
                  <i className="ri-tractor-line text-xl text-accent"></i>
                </div>
              </div>
              <div className="text-3xl font-bold text-neutral-800">{equipmentCount}</div>
              <p className="text-sm text-neutral-500 mt-1">
                Tractors, harvesters, and more
              </p>
            </motion.div>
          </div>
        </SlideUp>
        
        <MarketplaceSection viewAll />
        
        {/* Add Listing Dialog */}
        <Dialog open={showAddListingDialog} onOpenChange={setShowAddListingDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New {listingType === "land" ? "Land" : "Equipment"} Listing</DialogTitle>
              <DialogDescription>
                Create a new listing to rent, sell, or lease your agricultural {listingType}.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="bg-neutral-50 p-4 rounded-lg">
                <div className="flex items-start">
                  <div className={`bg-${listingType === "land" ? "secondary" : "accent"} bg-opacity-10 p-2 rounded-full mr-3`}>
                    <i className={`${listingType === "land" ? "ri-landscape-line" : "ri-tools-line"} text-xl text-${listingType === "land" ? "secondary" : "accent"}`}></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-neutral-800">
                      {listingType === "land" ? "Agricultural Land" : "Farm Equipment"}
                    </h3>
                    <p className="text-sm text-neutral-600 mt-1">
                      {listingType === "land" 
                        ? "Add details about your land, location, size, and features." 
                        : "Add details about your equipment, specifications, and rental terms."}
                    </p>
                  </div>
                </div>
              </div>
              
              <p className="text-sm text-neutral-600">
                By creating a listing, you agree to our terms of service and listing guidelines.
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowAddListingDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                className={`${listingType === "land" ? "bg-secondary" : "bg-accent"} hover:${listingType === "land" ? "bg-secondary-dark" : "bg-accent-dark"}`}
                onClick={handleCreateListing}
              >
                Continue
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </PageTransition>
  );
};

export default Marketplace;
