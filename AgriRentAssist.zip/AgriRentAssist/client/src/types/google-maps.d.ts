// Type definitions for Google Maps JavaScript API 3.51
// This is a simplified version of the full typings

declare namespace google {
  namespace maps {
    class Map {
      constructor(mapDiv: Element, opts?: MapOptions);
      fitBounds(bounds: LatLngBounds, padding?: number | Padding): void;
      getBounds(): LatLngBounds | undefined;
      getCenter(): LatLng | undefined;
      getZoom(): number | undefined;
      setCenter(latlng: LatLng | LatLngLiteral): void;
      setZoom(zoom: number): void;
      setOptions(options: MapOptions): void;
      panTo(latLng: LatLng | LatLngLiteral): void;
      panBy(x: number, y: number): void;
    }

    class Marker {
      constructor(opts?: MarkerOptions);
      setMap(map: Map | null): void;
      setPosition(latLng: LatLng | LatLngLiteral): void;
      setTitle(title: string): void;
      setLabel(label: string | MarkerLabel): void;
      setIcon(icon: string | Icon | Symbol): void;
      setOpacity(opacity: number): void;
      setVisible(visible: boolean): void;
      setZIndex(zIndex: number): void;
      getPosition(): LatLng | undefined;
      getLabel(): MarkerLabel | undefined;
      getMap(): Map | null | undefined;
      addListener(eventName: string, handler: Function): MapsEventListener;
      setAnimation(animation: Animation | null): void;
    }

    class InfoWindow {
      constructor(opts?: InfoWindowOptions);
      open(map?: Map, anchor?: MVCObject): void;
      close(): void;
      setContent(content: string | Element): void;
      setPosition(position: LatLng | LatLngLiteral): void;
      setZIndex(zIndex: number): void;
      getContent(): string | Element | undefined;
      getPosition(): LatLng | undefined;
      setOptions(options: InfoWindowOptions): void;
    }

    class LatLng {
      constructor(lat: number, lng: number, noWrap?: boolean);
      lat(): number;
      lng(): number;
      toString(): string;
      toUrlValue(precision?: number): string;
      equals(other: LatLng): boolean;
      toJSON(): LatLngLiteral;
    }

    class LatLngBounds {
      constructor(sw?: LatLng | LatLngLiteral, ne?: LatLng | LatLngLiteral);
      contains(latLng: LatLng | LatLngLiteral): boolean;
      equals(other: LatLngBounds | LatLngBoundsLiteral): boolean;
      extend(point: LatLng | LatLngLiteral): LatLngBounds;
      getCenter(): LatLng;
      getNorthEast(): LatLng;
      getSouthWest(): LatLng;
      isEmpty(): boolean;
      toJSON(): LatLngBoundsLiteral;
      toString(): string;
      toUrlValue(precision?: number): string;
      union(other: LatLngBounds | LatLngBoundsLiteral): LatLngBounds;
    }

    class MapsEventListener {
      remove(): void;
    }

    class MVCObject {
      addListener(eventName: string, handler: Function): MapsEventListener;
      bindTo(key: string, target: MVCObject, targetKey?: string, noNotify?: boolean): void;
      get(key: string): any;
      notify(key: string): void;
      set(key: string, value: any): void;
      setValues(values: any): void;
      unbind(key: string): void;
      unbindAll(): void;
    }

    enum MapTypeId {
      HYBRID = 'hybrid',
      ROADMAP = 'roadmap',
      SATELLITE = 'satellite',
      TERRAIN = 'terrain',
    }

    enum Animation {
      BOUNCE = 1,
      DROP = 2,
    }

    namespace SymbolPath {
      const BACKWARD_CLOSED_ARROW: number;
      const BACKWARD_OPEN_ARROW: number;
      const CIRCLE: number;
      const FORWARD_CLOSED_ARROW: number;
      const FORWARD_OPEN_ARROW: number;
    }

    namespace event {
      function addDomListener(
        instance: object,
        eventName: string,
        handler: Function,
        capture?: boolean
      ): MapsEventListener;
      function addDomListenerOnce(
        instance: object,
        eventName: string,
        handler: Function,
        capture?: boolean
      ): MapsEventListener;
      function addListener(instance: object, eventName: string, handler: Function): MapsEventListener;
      function addListenerOnce(instance: object, eventName: string, handler: Function): MapsEventListener;
      function clearInstanceListeners(instance: object): void;
      function clearListeners(instance: object, eventName: string): void;
      function removeListener(listener: MapsEventListener): void;
      function trigger(instance: any, eventName: string, ...args: any[]): void;
    }

    interface MapOptions {
      backgroundColor?: string;
      center?: LatLng | LatLngLiteral;
      clickableIcons?: boolean;
      controlSize?: number;
      disableDefaultUI?: boolean;
      disableDoubleClickZoom?: boolean;
      draggable?: boolean;
      draggableCursor?: string;
      draggingCursor?: string;
      fullscreenControl?: boolean;
      fullscreenControlOptions?: FullscreenControlOptions;
      gestureHandling?: 'cooperative' | 'greedy' | 'none' | 'auto';
      heading?: number;
      keyboardShortcuts?: boolean;
      mapTypeId?: MapTypeId;
      mapTypeControl?: boolean;
      mapTypeControlOptions?: MapTypeControlOptions;
      maxZoom?: number;
      minZoom?: number;
      noClear?: boolean;
      panControl?: boolean;
      panControlOptions?: PanControlOptions;
      restriction?: MapRestriction;
      rotateControl?: boolean;
      rotateControlOptions?: RotateControlOptions;
      scaleControl?: boolean;
      scaleControlOptions?: ScaleControlOptions;
      scrollwheel?: boolean;
      streetView?: StreetViewPanorama;
      streetViewControl?: boolean;
      streetViewControlOptions?: StreetViewControlOptions;
      styles?: MapTypeStyle[];
      tilt?: number;
      zoom?: number;
      zoomControl?: boolean;
      zoomControlOptions?: ZoomControlOptions;
    }

    interface PanControlOptions {
      position?: ControlPosition;
    }

    interface ZoomControlOptions {
      position?: ControlPosition;
    }

    interface ScaleControlOptions {
      style?: ScaleControlStyle;
    }

    interface RotateControlOptions {
      position?: ControlPosition;
    }

    interface StreetViewControlOptions {
      position?: ControlPosition;
    }

    interface FullscreenControlOptions {
      position?: ControlPosition;
    }

    interface MapTypeControlOptions {
      mapTypeIds?: (MapTypeId | string)[];
      position?: ControlPosition;
      style?: MapTypeControlStyle;
    }

    interface MapRestriction {
      latLngBounds: LatLngBounds | LatLngBoundsLiteral;
      strictBounds?: boolean;
    }

    interface MapTypeStyle {
      elementType?: string;
      featureType?: string;
      stylers: MapTypeStyler[];
    }

    interface MapTypeStyler {
      [key: string]: string | number | boolean;
    }

    enum MapTypeControlStyle {
      DEFAULT = 0,
      DROPDOWN_MENU = 2,
      HORIZONTAL_BAR = 1,
    }

    enum ScaleControlStyle {
      DEFAULT = 0,
    }

    enum ControlPosition {
      BOTTOM = 11,
      BOTTOM_CENTER = 11,
      BOTTOM_LEFT = 10,
      BOTTOM_RIGHT = 12,
      CENTER = 13,
      LEFT = 5,
      LEFT_BOTTOM = 6,
      LEFT_CENTER = 4,
      LEFT_TOP = 5,
      RIGHT = 7,
      RIGHT_BOTTOM = 9,
      RIGHT_CENTER = 8,
      RIGHT_TOP = 7,
      TOP = 2,
      TOP_CENTER = 2,
      TOP_LEFT = 1,
      TOP_RIGHT = 3,
    }

    interface MarkerOptions {
      position: LatLng | LatLngLiteral;
      map?: Map;
      animation?: Animation;
      clickable?: boolean;
      crossOnDrag?: boolean;
      cursor?: string;
      draggable?: boolean;
      icon?: string | Icon | Symbol;
      label?: string | MarkerLabel;
      opacity?: number;
      optimized?: boolean;
      title?: string;
      visible?: boolean;
      zIndex?: number;
    }

    interface MarkerLabel {
      color?: string;
      fontFamily?: string;
      fontSize?: string;
      fontWeight?: string;
      text: string;
    }

    interface Icon {
      anchor?: Point;
      labelOrigin?: Point;
      origin?: Point;
      scaledSize?: Size;
      size?: Size;
      url: string;
    }

    interface Symbol {
      anchor?: Point;
      fillColor?: string;
      fillOpacity?: number;
      labelOrigin?: Point;
      path: string | number;
      rotation?: number;
      scale?: number;
      strokeColor?: string;
      strokeOpacity?: number;
      strokeWeight?: number;
    }

    interface InfoWindowOptions {
      ariaLabel?: string;
      content?: string | Element;
      disableAutoPan?: boolean;
      maxWidth?: number;
      minWidth?: number;
      pixelOffset?: Size;
      position?: LatLng | LatLngLiteral;
      zIndex?: number;
    }

    class Point {
      constructor(x: number, y: number);
      x: number;
      y: number;
      equals(other: Point): boolean;
      toString(): string;
    }

    class Size {
      constructor(width: number, height: number, widthUnit?: string, heightUnit?: string);
      width: number;
      height: number;
      equals(other: Size): boolean;
      toString(): string;
    }

    interface StreetViewPanorama {
      // Define properties as needed
    }

    interface LatLngLiteral {
      lat: number;
      lng: number;
    }

    interface LatLngBoundsLiteral {
      east: number;
      north: number;
      south: number;
      west: number;
    }

    interface Padding {
      bottom: number;
      left: number;
      right: number;
      top: number;
    }
  }
}

// Extend the Window interface
interface Window {
  google?: typeof google;
}