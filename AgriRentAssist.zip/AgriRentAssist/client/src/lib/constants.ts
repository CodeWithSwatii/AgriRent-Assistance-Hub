export const WEBSITE_NAME = "AgriRent Assistance Hub";

export const WEATHER_API_KEY = import.meta.env.VITE_WEATHER_API_KEY || "demo_key";
export const MAPS_API_KEY = import.meta.env.VITE_MAPS_API_KEY || "demo_key";

export const NAVIGATION_LINKS = [
  { name: "Dashboard", href: "/dashboard" },
  { name: "Rental", href: "/marketplace" },
  { name: "Crop Analysis", href: "/crop-analysis" },
  { name: "Weather", href: "/weather" },
  { name: "Market Prices", href: "/market-prices" },
];

export const THEME_COLORS = {
  primary: {
    DEFAULT: '#2D7738',
    light: '#3A9949',
    dark: '#1E5128'
  },
  secondary: {
    DEFAULT: '#8B5A2B',
    light: '#A36B33',
    dark: '#6A4522'
  },
  accent: {
    DEFAULT: '#E3B448',
    light: '#EECA71',
    dark: '#C99A31'
  },
  success: '#4CAF50',
  warning: '#FFA000',
  error: '#E53935',
};

export const MARKETS = [
  "Maharashtra",
  "Punjab",
  "Haryana",
  "Karnataka",
  "Uttar Pradesh",
  "Gujarat",
  "Rajasthan",
];

export const LAND_TRANSACTION_TYPES = [
  { value: "rent", label: "For Rent" },
  { value: "sale", label: "For Sale" },
  { value: "lease", label: "For Lease" },
];

export const LAND_TYPES = [
  { value: "agricultural", label: "Agricultural Land" },
  { value: "farmhouse", label: "Farm House" },
  { value: "orchard", label: "Orchard" },
  { value: "plantation", label: "Plantation" },
];

export const EQUIPMENT_TYPES = [
  { value: "tractor", label: "Tractor" },
  { value: "harvester", label: "Harvester" },
  { value: "thresher", label: "Thresher" },
  { value: "seeder", label: "Seeder" },
  { value: "irrigation", label: "Irrigation Equipment" },
  { value: "storage", label: "Storage Equipment" },
];

export const PRICE_RANGES = [
  { value: "any", label: "Any Price" },
  { value: "under_10000", label: "Under ₹10,000" },
  { value: "10000_50000", label: "₹10,000 - ₹50,000" },
  { value: "50000_100000", label: "₹50,000 - ₹1,00,000" },
  { value: "above_100000", label: "Above ₹1,00,000" },
];

export const WEATHER_ICONS = {
  Sunny: "ri-sun-line",
  "Partly Cloudy": "ri-sun-cloudy-line",
  Cloudy: "ri-cloudy-line",
  Rainy: "ri-drizzle-line",
  Stormy: "ri-thunderstorms-line",
  Snowy: "ri-snowy-line",
};

export const DAYS_OF_WEEK = [
  "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
];
