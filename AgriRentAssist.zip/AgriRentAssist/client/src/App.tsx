import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AnimatePresence } from "framer-motion";
import NavigationBar from "@/components/layout/navigation-bar";
import Footer from "@/components/layout/footer";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/ui/protected-route";

// Pages
import Home from "@/pages/home";
import Dashboard from "@/pages/dashboard";
import CropAnalysis from "@/pages/crop-analysis";
import Marketplace from "@/pages/marketplace";
import Weather from "@/pages/weather";
import MarketPrices from "@/pages/market-prices";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <AnimatePresence mode="wait">
      <Switch>
        <Route path="/" component={Home} />
        <ProtectedRoute path="/dashboard" component={Dashboard} />
        <ProtectedRoute path="/crop-analysis" component={CropAnalysis} />
        <ProtectedRoute path="/marketplace" component={Marketplace} />
        <ProtectedRoute path="/weather" component={Weather} />
        <ProtectedRoute path="/market-prices" component={MarketPrices} />
        <Route path="/auth" component={AuthPage} />
        <Route component={NotFound} />
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="flex flex-col min-h-screen">
          <NavigationBar />
          <main className="flex-grow">
            <Router />
          </main>
          <Footer />
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
